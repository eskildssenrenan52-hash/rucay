// Monster definitions + spawning tied to biomes. Enemy stats scale with the
// biome's enemy level (further biome + deeper floor = stronger).

import { BiomeDef, WorldLoc, enemyLevel, biomeAt } from './biomes';
import { enemyScale } from './attributes';

export interface MonsterDef {
  key: string;
  name: string;
  baseHp: number;
  baseAtk: number;
  xp: number;
  gold: [number, number];
  idle: string; // IMG key
  move: string; // IMG key
  speed: number;
}

// Reuses the original sprite assets (enemy/NPC sprites are kept as requested).
export const MONSTER_DEFS: Record<string, MonsterDef> = {
  rat: { key: 'rat', name: 'Rato Gigante', baseHp: 15, baseAtk: 3, xp: 4, gold: [1, 3], idle: 'ratIdle', move: 'ratMove', speed: 1.3 },
  slime: { key: 'slime', name: 'Gosma Ácida', baseHp: 20, baseAtk: 4, xp: 6, gold: [1, 4], idle: 'slimeIdle', move: 'slimeMove', speed: 0.9 },
  goblin: { key: 'goblin', name: 'Goblin', baseHp: 25, baseAtk: 5, xp: 8, gold: [2, 6], idle: 'goblinIdle', move: 'goblinMove', speed: 1.2 },
  goblinwar: { key: 'goblinwar', name: 'Goblin Guerreiro', baseHp: 40, baseAtk: 8, xp: 14, gold: [4, 9], idle: 'goblinIdle', move: 'goblinWarMove', speed: 1.2 },
  wolf: { key: 'wolf', name: 'Lobo Selvagem', baseHp: 30, baseAtk: 9, xp: 10, gold: [2, 5], idle: 'wolfIdle', move: 'wolfMove', speed: 1.6 },
  zombie: { key: 'zombie', name: 'Zumbi', baseHp: 45, baseAtk: 6, xp: 13, gold: [3, 7], idle: 'zombieIdle', move: 'zombieMove', speed: 0.8 },
  skeleton: { key: 'skeleton', name: 'Esqueleto', baseHp: 35, baseAtk: 7, xp: 12, gold: [3, 8], idle: 'skeletonIdle', move: 'skeletonMove', speed: 1.1 },
  skeletonwar: { key: 'skeletonwar', name: 'Esqueleto Guerreiro', baseHp: 55, baseAtk: 10, xp: 20, gold: [6, 12], idle: 'skeletonIdle', move: 'skeletonWarMove', speed: 1.1 },
  ogre: { key: 'ogre', name: 'Ogro', baseHp: 90, baseAtk: 15, xp: 35, gold: [10, 20], idle: 'ogreIdle', move: 'ogreMove', speed: 1.0 },
  // Kobolds — small, agile reptilian humanoids (reuse goblin sprites, scaled stats)
  kobold: { key: 'kobold', name: 'Kobold', baseHp: 28, baseAtk: 6, xp: 9, gold: [2, 6], idle: 'goblinIdle', move: 'goblinMove', speed: 1.4 },
  koboldwar: { key: 'koboldwar', name: 'Kobold Guerreiro', baseHp: 48, baseAtk: 9, xp: 16, gold: [4, 10], idle: 'goblinIdle', move: 'goblinWarMove', speed: 1.4 },
  // Lizard Men — bestial reptilian warriors (reuse wolf/ogre sprites)
  lizardman: { key: 'lizardman', name: 'Lizard Man', baseHp: 60, baseAtk: 11, xp: 22, gold: [6, 12], idle: 'wolfIdle', move: 'wolfMove', speed: 1.3 },
  lizardwar: { key: 'lizardwar', name: 'Lizard Man Guerreiro', baseHp: 85, baseAtk: 14, xp: 30, gold: [8, 16], idle: 'ogreIdle', move: 'ogreMove', speed: 1.1 },
  // Ice spiders — reuse slime sprites (blob-like)
  icespider: { key: 'icespider', name: 'Aranha de Gelo', baseHp: 55, baseAtk: 10, xp: 18, gold: [4, 9], idle: 'slimeIdle', move: 'slimeMove', speed: 1.5 },
  frostwolf: { key: 'frostwolf', name: 'Lobo Gélido', baseHp: 70, baseAtk: 12, xp: 24, gold: [5, 11], idle: 'wolfIdle', move: 'wolfMove', speed: 1.6 },
  // Giant spiders — reuse slime/rat sprites
  giantspider: { key: 'giantspider', name: 'Aranha Gigante', baseHp: 75, baseAtk: 13, xp: 26, gold: [6, 12], idle: 'slimeIdle', move: 'slimeMove', speed: 1.4 },
  poisonspider: { key: 'poisonspider', name: 'Aranha Venenosa', baseHp: 50, baseAtk: 11, xp: 20, gold: [4, 10], idle: 'ratIdle', move: 'ratMove', speed: 1.7 },
  // Tritons / merfolk — reuse skeleton/zombie sprites (aquatic humanoids)
  triton: { key: 'triton', name: 'Tritão', baseHp: 95, baseAtk: 15, xp: 32, gold: [8, 16], idle: 'skeletonIdle', move: 'skeletonMove', speed: 1.2 },
  merfolk: { key: 'merfolk', name: 'Tritão Guerreiro', baseHp: 120, baseAtk: 17, xp: 40, gold: [10, 20], idle: 'skeletonIdle', move: 'skeletonWarMove', speed: 1.2 },
  // Fire elementals / lava beasts — reuse ogre sprites (large fiery)
  firelemental: { key: 'firelemental', name: 'Elemental de Fogo', baseHp: 110, baseAtk: 18, xp: 38, gold: [10, 20], idle: 'ogreIdle', move: 'ogreMove', speed: 1.1 },
  lavabeast: { key: 'lavabeast', name: 'Besta de Lava', baseHp: 140, baseAtk: 20, xp: 45, gold: [12, 24], idle: 'ogreIdle', move: 'ogreMove', speed: 1.0 },
  // Mushroom creatures — reuse slime/zombie sprites
  mushroomman: { key: 'mushroomman', name: 'Cogumelo Vivo', baseHp: 130, baseAtk: 16, xp: 42, gold: [10, 22], idle: 'zombieIdle', move: 'zombieMove', speed: 0.9 },
  sporebeast: { key: 'sporebeast', name: 'Besta de Esporos', baseHp: 100, baseAtk: 19, xp: 36, gold: [8, 18], idle: 'slimeIdle', move: 'slimeMove', speed: 1.1 },
};

export interface Monster {
  def: MonsterDef;
  x: number; y: number;
  homeX: number; homeY: number;
  hp: number; maxHp: number;
  atk: number; xp: number; gold: [number, number];
  level: number;
  alive: boolean;
  moving: boolean;
  cd: number;
  hitFlash: number;
  wanderT: number;
  wx: number; wy: number;
  dir: number;
}

function mulberry32(seed: number) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function spawnForBiome(
  loc: WorldLoc,
  mapW: number, mapH: number,
  tileSize: number,
  isBlocked: (tx: number, ty: number) => boolean,
  seed: number,
  count: number,
): Monster[] {
  const biome = biomeAt(loc);
  const lvl = enemyLevel(loc);
  const r = mulberry32(seed + lvl * 13 + biome.order * 7);
  const out: Monster[] = [];
  let attempts = 0;
  while (out.length < count && attempts < count * 40) {
    attempts++;
    const tx = Math.floor(r() * mapW);
    const ty = Math.floor(r() * mapH);
    if (isBlocked(tx, ty)) continue;
    const key = biome.monsterKeys[Math.floor(r() * biome.monsterKeys.length)];
    const def = MONSTER_DEFS[key];
    const scale = enemyScale(lvl);
    const hp = Math.round(def.baseHp * scale);
    const atk = Math.round(def.baseAtk * scale);
    const xp = Math.round(def.xp * scale);
    const gold: [number, number] = [def.gold[0], def.gold[1] + Math.floor(lvl / 3)];
    out.push({
      def, x: tx * tileSize + tileSize / 2, y: ty * tileSize + tileSize / 2,
      homeX: tx * tileSize + tileSize / 2, homeY: ty * tileSize + tileSize / 2,
      hp, maxHp: hp, atk, xp, gold, level: lvl, alive: true, moving: false,
      cd: 0, hitFlash: 0, wanderT: r() * 100, wx: 0, wy: 0, dir: 1,
    });
  }
  return out;
}

export function maxMonstersFor(biome: BiomeDef): number {
  return Math.round(60 * biome.monsterDensity / 0.09);
}
