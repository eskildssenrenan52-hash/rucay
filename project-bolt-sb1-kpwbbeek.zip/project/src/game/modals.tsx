// All modal panels for the mobile game UI — premium, detailed, animated.
// Each modal is a self-contained component with rich visual feedback.

import { useState } from 'react';
import { ATTRIBUTES, AttrMap, DerivedStats, CLASS_DEFS } from './attributes';
import { BIOMES } from './biomes';
import { MONSTER_DEFS } from './monsters';
import { worldMapNodes } from './worldmap';

const ASSET = (n: string) => `assets/${n}-default-000.png`;

// ---- Shared premium shell ----
function ModalShell({ title, subtitle, onClose, children, accent = '#d9a441', icon }: {
  title: string; subtitle?: string; onClose: () => void; children: React.ReactNode; accent?: string; icon?: string;
}) {
  return (
    <div className="absolute inset-0 z-[30] flex items-end sm:items-center justify-center" onClick={onClose}
      style={{ background: 'rgba(5,3,1,0.85)', backdropFilter: 'blur(4px)' }}>
      <div
        className="w-full max-w-md max-h-[88vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl"
        style={{
          background: 'linear-gradient(180deg, #1f1812 0%, #15100a 100%)',
          border: `2px solid ${accent}`,
          boxShadow: `0 0 40px ${accent}33, inset 0 1px 0 rgba(255,255,255,0.05)`,
          animation: 'modalSlideUp 0.25s ease-out',
        }}
        onClick={e => e.stopPropagation()}
      >
        {/* header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-3"
          style={{ background: 'linear-gradient(180deg, #1f1812 0%, #1a1410cc 100%)', borderBottom: `1px solid ${accent}44` }}>
          <div className="flex items-center gap-2.5">
            {icon && <span className="text-xl">{icon}</span>}
            <div>
              <h2 className="text-base font-bold leading-tight" style={{ color: accent, textShadow: `0 0 12px ${accent}66` }}>{title}</h2>
              {subtitle && <p className="text-[10px] text-[#887] leading-tight mt-0.5">{subtitle}</p>}
            </div>
          </div>
          <button className="w-8 h-8 rounded-full flex items-center justify-center text-[#bba] text-lg transition-colors"
            style={{ background: '#2a1d10', border: `1px solid ${accent}44` }}
            onClick={onClose}>×</button>
        </div>
        {/* body */}
        <div className="p-4">
          {children}
        </div>
      </div>
    </div>
  );
}

// ---- shared components ----
function SectionLabel({ children, color = '#d9a441' }: { children: React.ReactNode; color?: string }) {
  return (
    <div className="flex items-center gap-2 mb-2 mt-3">
      <div className="h-px flex-1" style={{ background: `linear-gradient(90deg, ${color}66, transparent)` }} />
      <span className="text-[10px] font-bold uppercase tracking-wider" style={{ color }}>{children}</span>
      <div className="h-px flex-1" style={{ background: `linear-gradient(270deg, ${color}66, transparent)` }} />
    </div>
  );
}

function GlowCard({ children, accent, onClick, active }: { children: React.ReactNode; accent: string; onClick?: () => void; active?: boolean }) {
  return (
    <div
      className="rounded-xl p-3 transition-all"
      style={{
        background: active ? `linear-gradient(135deg, ${accent}22, #241a10)` : '#241a10',
        border: `1px solid ${active ? accent : '#3a2a16'}`,
        boxShadow: active ? `0 0 16px ${accent}33` : 'none',
        cursor: onClick ? 'pointer' : 'default',
      }}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

function MiniBar({ pct, from, to, h = 6 }: { pct: number; from: string; to: string; h?: number }) {
  return (
    <div className="w-full rounded-full overflow-hidden" style={{ height: h, background: '#0d0a07' }}>
      <div className="h-full rounded-full transition-all duration-300" style={{ width: `${Math.min(1, pct) * 100}%`, background: `linear-gradient(90deg, ${from}, ${to})` }} />
    </div>
  );
}

// ---- Status / Attributes ----
export function StatusModal({
  attrs, statPoints, classKey, classLevel, classXp, classXpNext, playerLevel,
  derived, onAddAttr, onClose,
}: {
  attrs: AttrMap; statPoints: number; classKey: string;
  classLevel: number; classXp: number; classXpNext: number; playerLevel: number;
  derived: DerivedStats;
  onAddAttr: (key: string) => void; onClose: () => void;
}) {
  const cls = CLASS_DEFS[classKey];
  return (
    <ModalShell title="Status do Herói" subtitle={`${cls?.name || ''} · Nível ${playerLevel}`} onClose={onClose} accent={cls?.color || '#d9a441'} icon="📊">
      {/* level cards */}
      <div className="grid grid-cols-2 gap-2.5 mb-2">
        <GlowCard accent="#58d68d">
          <div className="text-[10px] text-[#887] uppercase tracking-wide">Nível do Player</div>
          <div className="text-2xl font-bold text-[#58d68d]" style={{ textShadow: '0 0 10px #58d68d55' }}>{playerLevel}</div>
          <div className="text-[9px] text-[#887] mt-0.5">+5% poder por nível</div>
        </GlowCard>
        <GlowCard accent="#5dade2">
          <div className="text-[10px] text-[#887] uppercase tracking-wide">Nível da Classe</div>
          <div className="text-2xl font-bold text-[#5dade2]" style={{ textShadow: '0 0 10px #5dade255' }}>{classLevel}</div>
          <div className="text-[9px] text-[#887] mt-0.5">+2 pts atributo por nível</div>
        </GlowCard>
      </div>

      {/* XP bars */}
      <div className="space-y-1.5 mb-1">
        <div>
          <div className="flex justify-between text-[9px] text-[#887] mb-0.5"><span>XP Player</span><span>{classXp}/{classXpNext}</span></div>
          <MiniBar pct={classXp / classXpNext} from="#58d68d" to="#27ae60" />
        </div>
        <div>
          <div className="flex justify-between text-[9px] text-[#887] mb-0.5"><span>XP Classe</span><span>{classXp}/{classXpNext}</span></div>
          <MiniBar pct={classXp / classXpNext} from="#5dade2" to="#2980b9" />
        </div>
      </div>

      {statPoints > 0 && (
        <div className="my-2 px-3 py-2 rounded-lg flex items-center justify-between" style={{ background: 'linear-gradient(90deg, #d9a44122, #d9a44111)', border: '1px solid #d9a441' }}>
          <span className="text-xs text-[#d9a441] font-bold animate-pulse">{statPoints} pontos de atributo disponíveis!</span>
        </div>
      )}

      <SectionLabel color={cls?.color}>Atributos</SectionLabel>
      <div className="grid grid-cols-2 gap-2">
        {ATTRIBUTES.map(a => {
          const val = attrs[a.key] || 0;
          const isFavored = cls?.favored.includes(a.key);
          return (
            <div key={a.key} className="rounded-lg p-2 flex items-center gap-2"
              style={{ background: isFavored ? `${cls?.color}11` : '#1f1812', border: `1px solid ${isFavored ? cls?.color + '44' : '#2a1d10'}` }}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1">
                  <span className="text-[12px] text-gray-200 font-semibold">{a.name}</span>
                  {isFavored && <span className="text-[8px] px-1 rounded" style={{ background: cls?.color + '33', color: cls?.color }}>★</span>}
                </div>
                <div className="text-[9px] text-[#887] leading-tight truncate">{a.desc}</div>
              </div>
              <span className="text-base font-bold w-6 text-center" style={{ color: cls?.color, textShadow: `0 0 8px ${cls?.color}44` }}>{val}</span>
              <button
                className="w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold transition-all active:scale-90 disabled:opacity-20"
                style={{ background: statPoints > 0 ? `${cls?.color}33` : '#2a1d10', border: `1px solid ${statPoints > 0 ? cls?.color : '#3a2a16'}`, color: statPoints > 0 ? cls?.color : '#887' }}
                disabled={statPoints <= 0}
                onClick={() => onAddAttr(a.key)}
              >+</button>
            </div>
          );
        })}
      </div>

      <SectionLabel color={cls?.color}>Estatísticas Derivadas</SectionLabel>
      <div className="grid grid-cols-2 gap-1.5">
        <DerivedStat label="Vida Máxima" value={derived.maxHp} icon="❤" color="#e74c3c" />
        <DerivedStat label="Mana Máxima" value={derived.maxMp} icon="✦" color="#2980b9" />
        <DerivedStat label="Ataque" value={derived.atk} icon="⚔" color="#e67e22" />
        <DerivedStat label="Alcance" value={derived.range.toFixed(1)} icon="◎" color="#f39c12" />
        <DerivedStat label="Velocidade" value={derived.speed.toFixed(1)} icon="➤" color="#27ae60" />
        <DerivedStat label="Crítico" value={`${Math.round(derived.critChance * 100)}%`} icon="✦" color="#e74c3c" />
        <DerivedStat label="Esquiva" value={`${Math.round(derived.dodge * 100)}%`} icon="↪" color="#5dade2" />
        <DerivedStat label="Red. Dano" value={`${Math.round(derived.dmgReduction * 100)}%`} icon="🛡" color="#95a5a6" />
        <DerivedStat label="Regen HP" value={derived.hpRegen.toFixed(1)} icon="♥" color="#58d68d" />
        <DerivedStat label="Regen MP" value={derived.mpRegen.toFixed(1)} icon="✧" color="#5dade2" />
        <DerivedStat label="Ouro Extra" value={`+${Math.round((derived.goldFind - 1) * 100)}%`} icon="◈" color="#d9a441" />
        <DerivedStat label="Desconto Loja" value={`-${Math.round(derived.shopDiscount * 100)}%`} icon="$" color="#d9a441" />
      </div>
    </ModalShell>
  );
}

function DerivedStat({ label, value, icon, color }: { label: string; value: string | number; icon: string; color: string }) {
  return (
    <div className="flex items-center gap-2 rounded-lg px-2.5 py-1.5" style={{ background: '#1f1812', border: '1px solid #2a1d10' }}>
      <span className="text-sm w-4 text-center" style={{ color }}>{icon}</span>
      <div className="flex-1 min-w-0">
        <div className="text-[9px] text-[#887] leading-tight">{label}</div>
        <div className="text-[13px] text-gray-200 font-bold leading-tight">{value}</div>
      </div>
    </div>
  );
}

// ---- Inventory ----
export interface InvItem { key: string; name: string; img: string; qty: number; type: 'potion' | 'gear'; desc: string; rarity?: string; }
export function InventoryModal({ items, gold, onClose, onUse }: {
  items: InvItem[]; gold: number; onClose: () => void; onUse: (key: string) => void;
}) {
  const [selected, setSelected] = useState<string | null>(null);
  const sel = items.find(i => i.key === selected);
  const rarityColor: Record<string, string> = { common: '#aaa', rare: '#5dade2', epic: '#9b59b6', legendary: '#d9a441' };
  return (
    <ModalShell title="Inventário" subtitle={`${items.length} itens · ${gold} ouro`} onClose={onClose} accent="#27ae60" icon="🎒">
      {items.length === 0 ? (
        <div className="text-center py-10">
          <div className="text-4xl mb-3 opacity-30">📦</div>
          <p className="text-[#bba] text-sm">Seu inventário está vazio.</p>
          <p className="text-[#887] text-[11px] mt-1">Derrote inimigos e explore biomas para encontrar itens!</p>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-5 gap-2">
            {Array.from({ length: 20 }).map((_, i) => {
              const it = items[i];
              if (!it) return <div key={i} className="aspect-square rounded-lg border border-dashed border-[#2a1d10] bg-[#0d0a07]/50" />;
              const rc = rarityColor[it.rarity || 'common'] || '#aaa';
              return (
                <div key={i} className="aspect-square rounded-lg flex flex-col items-center justify-center p-1 cursor-pointer transition-all active:scale-95 relative"
                  style={{ background: `${rc}11`, border: `1px solid ${selected === it.key ? rc : rc + '44'}`, boxShadow: selected === it.key ? `0 0 12px ${rc}55` : 'none' }}
                  onClick={() => setSelected(it.key === selected ? null : it.key)}>
                  <img src={ASSET(it.img)} className="w-7 h-7" style={{ imageRendering: 'pixelated' }} />
                  {it.qty > 1 && <span className="absolute bottom-0.5 right-1 text-[9px] font-bold text-[#d9a441]" style={{ textShadow: '1px 1px 1px #000' }}>x{it.qty}</span>}
                </div>
              );
            })}
          </div>
          {sel && (
            <div className="mt-3 rounded-xl p-3" style={{ background: `${rarityColor[sel.rarity || 'common']}11`, border: `1px solid ${rarityColor[sel.rarity || 'common']}` }}>
              <div className="flex items-center gap-2 mb-1">
                <img src={ASSET(sel.img)} className="w-10 h-10" style={{ imageRendering: 'pixelated' }} />
                <div>
                  <div className="text-sm font-bold" style={{ color: rarityColor[sel.rarity || 'common'] }}>{sel.name}</div>
                  <div className="text-[10px] text-[#887]">{sel.desc}</div>
                </div>
              </div>
              <button className="w-full mt-2 py-2 rounded-lg text-sm font-bold transition-all active:scale-95"
                style={{ background: '#27ae6033', border: '1px solid #27ae60', color: '#27ae60' }}
                onClick={() => onUse(sel.key)}>Usar</button>
            </div>
          )}
        </>
      )}
    </ModalShell>
  );
}

// ---- World Map ----
export function WorldMapModal({ currentBiome, maxOrder, onClose }: {
  currentBiome: string; maxOrder: number; onClose: () => void;
}) {
  const nodes = worldMapNodes(currentBiome, maxOrder);
  const [hovered, setHovered] = useState<string | null>(null);
  const hov = nodes.find(n => n.biome.id === hovered);
  return (
    <ModalShell title="Mapa Mundi" subtitle="Aldenor e seus reinos" onClose={onClose} accent="#5dade2" icon="🗺️">
      <div className="relative w-full aspect-[4/3] rounded-xl overflow-hidden mb-3"
        style={{ background: 'radial-gradient(ellipse at center, #0d1a14 0%, #050302 100%)', border: '1px solid #2a3a2a' }}>
        {/* decorative ocean texture */}
        <svg viewBox="0 0 200 150" className="absolute inset-0 w-full h-full">
          <defs>
            <pattern id="waves" x="0" y="0" width="20" height="10" patternUnits="userSpaceOnUse">
              <path d="M0,5 Q5,0 10,5 T20,5" fill="none" stroke="#1a2a3a" strokeWidth="0.3" />
            </pattern>
          </defs>
          <rect x="0" y="0" width="200" height="150" fill="url(#waves)" />
          {/* continents */}
          <path d="M20,40 Q60,20 100,35 T180,50 Q190,80 170,110 T100,130 Q40,120 20,90 Z" fill="#1a2a1a" stroke="#2a4a2a" strokeWidth="0.8" />
          <path d="M40,60 Q70,50 100,60 T160,70" fill="none" stroke="#3a5a3a" strokeWidth="0.4" opacity="0.5" />
          <path d="M50,90 Q80,85 110,95 T170,100" fill="none" stroke="#3a5a3a" strokeWidth="0.4" opacity="0.5" />
          {/* mountains decoration */}
          {[[60,50],[100,45],[140,55],[80,100],[130,110]].map(([x,y]) => (
            <path key={`${x}-${y}`} d={`M${x},${y} L${x-3},${y+5} L${x+3},${y+5} Z`} fill="#3a4a3a" />
          ))}
        </svg>
        {nodes.map(n => {
          const isCurrent = n.biome.id === currentBiome;
          const isHover = n.biome.id === hovered;
          const color = n.unlocked ? (isCurrent ? '#d9a441' : '#5dade2') : '#555';
          return (
            <div key={n.biome.id} className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center cursor-pointer"
              style={{ left: `${n.x * 100}%`, top: `${n.y * 100}%`, zIndex: isHover ? 20 : 10 }}
              onClick={() => setHovered(n.biome.id === hovered ? null : n.biome.id)}>
              {isCurrent && <div className="absolute w-6 h-6 rounded-full animate-ping" style={{ background: color + '44' }} />}
              <div className="w-3.5 h-3.5 rounded-full border-2 transition-all"
                style={{ backgroundColor: color, borderColor: n.unlocked ? '#fff' : '#333', boxShadow: isHover ? `0 0 12px ${color}` : 'none', transform: isHover ? 'scale(1.4)' : 'scale(1)' }} />
              <div className="text-[7px] mt-0.5 text-center whitespace-nowrap font-semibold" style={{ color: n.unlocked ? '#ccc' : '#555', textShadow: '1px 1px 1px #000' }}>{n.biome.name}</div>
              <div className="text-[6px] text-[#887]">Nv.{n.biome.level}</div>
            </div>
          );
        })}
      </div>
      {/* detail panel */}
      {hov ? (
        <div className="rounded-xl p-3" style={{ background: '#1f1812', border: `1px solid ${hov.unlocked ? '#5dade2' : '#555'}` }}>
          <div className="flex items-center justify-between mb-1">
            <span className="text-sm font-bold" style={{ color: hov.unlocked ? '#5dade2' : '#666' }}>{hov.biome.name}</span>
            <span className="text-[10px] px-2 py-0.5 rounded-full" style={{ background: hov.unlocked ? '#27ae6022' : '#55555522', color: hov.unlocked ? '#27ae60' : '#888' }}>
              {hov.unlocked ? 'Desbloqueado' : 'Bloqueado'}
            </span>
          </div>
          <div className="text-[11px] text-[#bba] mb-1">Tema: {hov.biome.theme}</div>
          <div className="text-[11px] text-[#887]">Nível dos inimigos: {hov.biome.level} · 4 andares de profundidade</div>
        </div>
      ) : (
        <div className="flex items-center justify-center gap-4 text-[10px] text-[#887]">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#5dade2]" /> Disponível</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#d9a441]" /> Atual</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#555]" /> Bloqueado</span>
        </div>
      )}
    </ModalShell>
  );
}

// ---- Equipment ----
export interface EquipSlot { slot: string; name: string; img: string | null; stat?: string; }
export function EquipmentModal({ slots, onClose }: {
  slots: EquipSlot[]; onClose: () => void;
}) {
  return (
    <ModalShell title="Equipamento" subtitle="Sua armadura e armas" onClose={onClose} accent="#e67e22" icon="⚔️">
      {/* character silhouette */}
      <div className="flex justify-center mb-3">
        <div className="relative w-20 h-20 rounded-full flex items-center justify-center"
          style={{ background: 'radial-gradient(circle, #2a1d10 0%, #0d0a07 100%)', border: '2px solid #e67e22' }}>
          <span className="text-3xl opacity-40">🛡️</span>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-2.5">
        {slots.map(s => (
          <div key={s.slot} className="rounded-xl p-2.5 flex items-center gap-2.5"
            style={{ background: s.img ? 'linear-gradient(135deg, #e67e2222, #241a10)' : '#1f1812', border: `1px solid ${s.img ? '#e67e2244' : '#2a1d10'}` }}>
            <div className="w-11 h-11 rounded-lg flex items-center justify-center" style={{ background: '#0d0a07', border: '1px solid #3a2a16' }}>
              {s.img ? <img src={ASSET(s.img)} className="w-8 h-8" style={{ imageRendering: 'pixelated' }} /> : <span className="text-[#444] text-xs">vazio</span>}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[9px] text-[#887] uppercase tracking-wide">{s.slot}</div>
              <div className="text-[12px] text-gray-200 font-semibold truncate">{s.name}</div>
              {s.stat && <div className="text-[9px] text-[#e67e22] mt-0.5">{s.stat}</div>}
            </div>
          </div>
        ))}
      </div>
    </ModalShell>
  );
}

// ---- Skills / Abilities ----
export function SkillsModal({ classKey, classLevel, onClose }: {
  classKey: string; classLevel: number; onClose: () => void;
}) {
  const cls = CLASS_DEFS[classKey];
  const skills = classKey === 'guerreiro' ? [
    { name: 'Investida', desc: 'Avança e causa dano em linha reta.', lvl: 1, cost: '5 MP', type: 'Físico' },
    { name: 'Grito de Guerra', desc: '+20% de ataque por 10 segundos.', lvl: 3, cost: '15 MP', type: 'Buff' },
    { name: 'Escudo de Ferro', desc: 'Reduz 50% do dano recebido por 5s.', lvl: 5, cost: '20 MP', type: 'Defesa' },
    { name: 'Fúria Berserker', desc: 'Dobra o dano causado, mas perde defesa.', lvl: 8, cost: '30 MP', type: 'Fúria' },
    { name: 'Execução', desc: 'Dano massivo em inimigos com pouca vida.', lvl: 12, cost: '40 MP', type: 'Ultimate' },
  ] : classKey === 'arqueiro' ? [
    { name: 'Tiro Rápido', desc: 'Dispara 2 flechas em sequência rápida.', lvl: 1, cost: '5 MP', type: 'Físico' },
    { name: 'Flecha Envenenada', desc: 'Causa dano por veneno durante 5s.', lvl: 3, cost: '12 MP', type: 'Veneno' },
    { name: 'Chuva de Flechas', desc: 'Dispara flechas em área, dano múltiplo.', lvl: 5, cost: '25 MP', type: 'Área' },
    { name: 'Olho de Águia', desc: '+50% de chance de crítico por 8s.', lvl: 8, cost: '20 MP', type: 'Buff' },
    { name: 'Disparo Perfurante', desc: 'Flecha que atravessa todos os inimigos em linha.', lvl: 12, cost: '45 MP', type: 'Ultimate' },
  ] : [
    { name: 'Dardo Místico', desc: 'Disparo mágico rápido e preciso.', lvl: 1, cost: '5 MP', type: 'Mágico' },
    { name: 'Escudo Arcano', desc: 'Absorve dano usando sua mana.', lvl: 3, cost: '15 MP', type: 'Defesa' },
    { name: 'Bola de Fogo', desc: 'Explosão que causa dano em área.', lvl: 5, cost: '25 MP', type: 'Área' },
    { name: 'Teleporte', desc: 'Move instantaneamente para o cursor.', lvl: 8, cost: '20 MP', type: 'Mobilidade' },
    { name: 'Tempestade Arcana', desc: 'Dano mágico massivo em grande área.', lvl: 12, cost: '50 MP', type: 'Ultimate' },
  ];
  const typeColor: Record<string, string> = { 'Físico': '#e67e22', 'Buff': '#27ae60', 'Defesa': '#5dade2', 'Fúria': '#e74c3c', 'Ultimate': '#d9a441', 'Veneno': '#27ae60', 'Área': '#e74c3c', 'Mágico': '#9b59b6', 'Mobilidade': '#5dade2' };
  return (
    <ModalShell title="Habilidades" subtitle={`${cls?.name || ''} · Nível ${classLevel}`} onClose={onClose} accent="#9b59b6" icon="✨">
      <div className="space-y-2.5">
        {skills.map((s) => {
          const unlocked = classLevel >= s.lvl;
          const tc = typeColor[s.type] || '#9b59b6';
          return (
            <div key={s.name} className="rounded-xl p-3 transition-all"
              style={{
                background: unlocked ? `linear-gradient(135deg, ${tc}11, #241a10)` : '#1a1410',
                border: `1px solid ${unlocked ? tc + '66' : '#2a1d10'}`,
                opacity: unlocked ? 1 : 0.5,
              }}>
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-xl flex flex-col items-center justify-center flex-shrink-0"
                  style={{ background: unlocked ? `${tc}22` : '#2a1d10', border: `1px solid ${unlocked ? tc : '#3a2a16'}` }}>
                  <span className="text-[10px] font-bold" style={{ color: unlocked ? tc : '#555' }}>Nv</span>
                  <span className="text-sm font-bold" style={{ color: unlocked ? tc : '#555' }}>{s.lvl}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-[13px] text-gray-200 font-bold">{s.name}</span>
                    <span className="text-[8px] px-1.5 py-0.5 rounded-full" style={{ background: tc + '22', color: tc }}>{s.type}</span>
                  </div>
                  <div className="text-[10px] text-[#887] leading-tight mt-0.5">{s.desc}</div>
                  <div className="text-[9px] text-[#5dade2] mt-0.5">{s.cost}</div>
                </div>
                <div className="flex-shrink-0">
                  {unlocked
                    ? <span className="text-[9px] font-bold px-2 py-1 rounded-full" style={{ background: '#27ae6022', color: '#27ae60', border: '1px solid #27ae60' }}>ATIVO</span>
                    : <span className="text-[9px] text-[#887]">Nv.{s.lvl}</span>}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </ModalShell>
  );
}

// ---- Bestiary ----
export function BestiaryModal({ kills, onClose }: { kills: Record<string, number>; onClose: () => void }) {
  const [expanded, setExpanded] = useState<string | null>(null);
  return (
    <ModalShell title="Bestiário" subtitle="Conheça seus inimigos" onClose={onClose} accent="#c0392b" icon="📖">
      <div className="space-y-2">
        {BIOMES.map(b => {
          const isExp = expanded === b.id;
          return (
            <div key={b.id} className="rounded-xl overflow-hidden transition-all"
              style={{ background: '#1f1812', border: `1px solid ${isExp ? b.ambient.replace('rgba(', 'rgb(').replace(/,0\.\d+\)/, ')') : '#2a1d10'}` }}>
              <div className="flex items-center justify-between p-2.5 cursor-pointer" onClick={() => setExpanded(isExp ? null : b.id)}>
                <div>
                  <div className="text-[13px] font-bold text-gray-200">{b.name}</div>
                  <div className="text-[10px] text-[#887]">{b.theme} · Nv.{b.level}</div>
                </div>
                <span className="text-[#887] text-sm">{isExp ? '▲' : '▼'}</span>
              </div>
              {isExp && (
                <div className="px-2.5 pb-2.5 space-y-1.5">
                  {b.monsterKeys.map(mk => {
                    const m = MONSTER_DEFS[mk];
                    if (!m) return null;
                    const killCount = kills[mk] || 0;
                    return (
                      <div key={mk} className="flex items-center gap-2.5 rounded-lg p-2" style={{ background: '#0d0a07', border: '1px solid #2a1d10' }}>
                        <img src={ASSET(m.idle.replace('Idle', 'agaichado'))} className="w-9 h-9" style={{ imageRendering: 'pixelated' }} />
                        <div className="flex-1 min-w-0">
                          <div className="text-[12px] text-gray-200 font-semibold">{m.name}</div>
                          <div className="flex gap-2 text-[9px] text-[#887]">
                            <span>HP {m.baseHp}</span>
                            <span>ATK {m.baseAtk}</span>
                            <span>XP {m.xp}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-[9px] text-[#887]">Derrotas</div>
                          <div className="text-sm font-bold" style={{ color: killCount > 0 ? '#d9a441' : '#555' }}>{killCount}</div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </ModalShell>
  );
}

// ---- Quests / Journal ----
export interface Quest { id: string; name: string; desc: string; progress: number; total: number; reward: string; }
export function QuestsModal({ quests, onClose }: {
  quests: Quest[]; onClose: () => void;
}) {
  const active = quests.filter(q => q.progress < q.total);
  const done = quests.filter(q => q.progress >= q.total);
  return (
    <ModalShell title="Diário de Missões" subtitle={`${active.length} ativas · ${done.length} completas`} onClose={onClose} accent="#f39c12" icon="📜">
      {quests.length === 0 ? (
        <div className="text-center py-10">
          <div className="text-4xl mb-3 opacity-30">📜</div>
          <p className="text-[#bba] text-sm">Nenhuma missão ativa.</p>
          <p className="text-[#887] text-[11px] mt-1">Explore os biomas para encontrar missões!</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {active.map(q => (
            <div key={q.id} className="rounded-xl p-3" style={{ background: 'linear-gradient(135deg, #f39c1211, #241a10)', border: '1px solid #f39c1244' }}>
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#f39c12] animate-pulse" />
                  <span className="text-[13px] text-gray-200 font-bold">{q.name}</span>
                </div>
                <span className="text-[10px] text-[#d9a441] font-bold">{q.progress}/{q.total}</span>
              </div>
              <div className="text-[11px] text-[#887] mb-2">{q.desc}</div>
              <MiniBar pct={q.progress / q.total} from="#f39c12" to="#e67e22" h={5} />
              <div className="flex items-center gap-1 mt-2 text-[10px]">
                <span className="text-[#887]">Recompensa:</span>
                <span className="text-[#58d68d] font-bold">{q.reward}</span>
              </div>
            </div>
          ))}
          {done.length > 0 && <SectionLabel color="#58d68d">Completas</SectionLabel>}
          {done.map(q => (
            <div key={q.id} className="rounded-xl p-3 opacity-60" style={{ background: '#241a10', border: '1px solid #27ae6044' }}>
              <div className="flex items-center justify-between mb-1">
                <div className="flex items-center gap-2">
                  <span className="text-[#58d68d]">✓</span>
                  <span className="text-[13px] text-gray-200 font-bold line-through">{q.name}</span>
                </div>
                <span className="text-[10px] text-[#58d68d]">COMPLETA</span>
              </div>
              <div className="text-[11px] text-[#887]">{q.desc}</div>
            </div>
          ))}
        </div>
      )}
    </ModalShell>
  );
}

// ---- Settings ----
export function SettingsModal({ soundOn, onToggleSound, onReset, onClose }: {
  soundOn: boolean; onToggleSound: () => void; onReset: () => void; onClose: () => void;
}) {
  const [confirmReset, setConfirmReset] = useState(false);
  return (
    <ModalShell title="Configurações" subtitle="Preferências do jogo" onClose={onClose} accent="#95a5a6" icon="⚙️">
      <div className="space-y-3">
        {/* sound toggle */}
        <div className="flex items-center justify-between rounded-xl p-3" style={{ background: '#241a10', border: '1px solid #3a2a16' }}>
          <div className="flex items-center gap-2.5">
            <span className="text-lg">{soundOn ? '🔊' : '🔇'}</span>
            <div>
              <div className="text-sm text-gray-200 font-semibold">Som</div>
              <div className="text-[10px] text-[#887]">Efeitos sonoros do jogo</div>
            </div>
          </div>
          <button className="w-12 h-7 rounded-full transition-all relative" onClick={onToggleSound}
            style={{ background: soundOn ? '#27ae60' : '#555' }}>
            <div className="absolute top-0.5 w-6 h-6 rounded-full bg-white transition-all" style={{ left: soundOn ? '26px' : '2px' }} />
          </button>
        </div>

        {/* quality of life info */}
        <div className="rounded-xl p-3" style={{ background: '#1f1812', border: '1px solid #2a1d10' }}>
          <div className="text-[11px] text-[#887] uppercase tracking-wide mb-1.5">Controles</div>
          <div className="space-y-1 text-[11px] text-[#bba]">
            <div className="flex justify-between"><span>Joystick</span><span className="text-[#887]">Mover</span></div>
            <div className="flex justify-between"><span>ATK</span><span className="text-[#887]">Atacar</span></div>
            <div className="flex justify-between"><span>INT</span><span className="text-[#887]">Interagir</span></div>
            <div className="flex justify-between"><span>HP/MP</span><span className="text-[#887]">Poções</span></div>
          </div>
        </div>

        {/* reset */}
        {!confirmReset ? (
          <button className="w-full rounded-xl p-3 text-sm font-semibold transition-all active:scale-95"
            style={{ background: '#3a1010', border: '1px solid #5c1d1e', color: '#ff6b6b' }}
            onClick={() => setConfirmReset(true)}>
            Recomeçar jogo
          </button>
        ) : (
          <div className="rounded-xl p-3" style={{ background: '#3a1010', border: '1px solid #c0392b' }}>
            <div className="text-sm text-[#ff6b6b] font-bold mb-2">Tem certeza? Todo o progresso será perdido.</div>
            <div className="flex gap-2">
              <button className="flex-1 py-2 rounded-lg text-sm font-bold" style={{ background: '#c0392b', color: '#fff' }} onClick={onReset}>Sim, recomeçar</button>
              <button className="flex-1 py-2 rounded-lg text-sm" style={{ background: '#2a1d10', border: '1px solid #3a2a16', color: '#bba' }} onClick={() => setConfirmReset(false)}>Cancelar</button>
            </div>
          </div>
        )}

        <div className="text-center pt-2">
          <div className="text-[10px] text-[#887]">Aldenor — Crônicas Esquecidas</div>
          <div className="text-[9px] text-[#555]">v3.0 · Mobile Edition</div>
        </div>
      </div>
    </ModalShell>
  );
}
