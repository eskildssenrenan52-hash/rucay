// Procedural stylized tile renderer — each tile is drawn with layered detail,
// never a flat single color. Tiles are cached to offscreen canvases for perf.

export type TileKind =
  | 'grass' | 'dirt' | 'stone' | 'sand' | 'water'
  | 'cryptFloor' | 'cryptWall' | 'ruinsFloor' | 'ruinsWall'
  | 'goldFloor' | 'goldWall' | 'lava' | 'ice' | 'snow'
  | 'swamp' | 'mossyStone' | 'crackedStone' | 'ash' | 'crystal'
  | 'caveSand' | 'scaleFloor' | 'scaleWall'
  | 'frozenFloor' | 'frozenWall' | 'webFloor' | 'webWall'
  | 'coralFloor' | 'coralWall' | 'volcanicFloor' | 'volcanicWall'
  | 'mushroomFloor' | 'mushroomWall';

const TILE = 40;

// Deterministic PRNG so a given tile renders identically every frame.
function mulberry32(seed: number) {
  return function () {
    seed |= 0; seed = (seed + 0x6D2B79F5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function hash3(x: number, y: number, salt: number) {
  let h = x * 374761393 + y * 668265263 + salt * 2147483647;
  h = (h ^ (h >>> 13)) * 1274126177;
  return ((h ^ (h >>> 16)) >>> 0) / 4294967296;
}

type RGB = [number, number, number];
function mix(a: RGB, b: RGB, t: number): RGB {
  return [
    Math.round(a[0] + (b[0] - a[0]) * t),
    Math.round(a[1] + (b[1] - a[1]) * t),
    Math.round(a[2] + (b[2] - a[2]) * t),
  ];
}
function rgb(c: RGB, a = 1) {
  return `rgba(${c[0]},${c[1]},${c[2]},${a})`;
}

const cache = new Map<string, HTMLCanvasElement>();

function makeCanvas(): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const cv = document.createElement('canvas');
  cv.width = TILE; cv.height = TILE;
  const c = cv.getContext('2d')!;
  c.imageSmoothingEnabled = false;
  return [cv, c];
}

function speckle(c: CanvasRenderingContext2D, _base: RGB, variants: RGB[], density: number, seed: number) {
  const r = mulberry32(seed);
  const n = Math.floor(density);
  for (let i = 0; i < n; i++) {
    const x = Math.floor(r() * TILE);
    const y = Math.floor(r() * TILE);
    const v = variants[Math.floor(r() * variants.length)];
    const s = 1 + Math.floor(r() * 2);
    c.fillStyle = rgb(v, 0.5 + r() * 0.4);
    c.fillRect(x, y, s, s);
  }
}

function vignette(c: CanvasRenderingContext2D, dark: RGB) {
  const g = c.createRadialGradient(TILE / 2, TILE / 2, 6, TILE / 2, TILE / 2, TILE * 0.75);
  g.addColorStop(0, 'rgba(0,0,0,0)');
  g.addColorStop(1, rgb(dark, 0.28));
  c.fillStyle = g;
  c.fillRect(0, 0, TILE, TILE);
}

function edgeShade(c: CanvasRenderingContext2D, light: RGB, dark: RGB) {
  // top highlight, bottom shadow for fake depth
  const tg = c.createLinearGradient(0, 0, 0, TILE);
  tg.addColorStop(0, rgb(light, 0.18));
  tg.addColorStop(0.5, 'rgba(0,0,0,0)');
  tg.addColorStop(1, rgb(dark, 0.22));
  c.fillStyle = tg;
  c.fillRect(0, 0, TILE, TILE);
}

function renderTile(kind: TileKind, variant: number): HTMLCanvasElement {
  const key = `${kind}:${variant}`;
  const cached = cache.get(key);
  if (cached) return cached;

  const [cv, c] = makeCanvas();
  const seed = variant * 97 + 13;

  switch (kind) {
    case 'grass': {
      const base: RGB = [74, 124, 58];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      // soil patches
      speckle(c, base, [[92, 70, 48], [110, 86, 60], [60, 100, 46]], 60, seed);
      // grass blades
      const r = mulberry32(seed + 5);
      for (let i = 0; i < 40; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        const g = mix([96, 160, 72], [54, 96, 40], r());
        c.fillStyle = rgb(g, 0.85);
        c.fillRect(x, y, 1, 2 + Math.floor(r() * 2));
      }
      // tiny flowers
      for (let i = 0; i < 3; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        const fc: RGB = r() > 0.5 ? [240, 210, 90] : [220, 120, 150];
        c.fillStyle = rgb(fc); c.fillRect(x, y, 2, 2);
      }
      edgeShade(c, [120, 180, 90], [40, 70, 30]);
      break;
    }
    case 'dirt': {
      const base: RGB = [110, 80, 54];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[130, 96, 64], [86, 60, 40], [140, 104, 70]], 80, seed);
      // pebbles
      const r = mulberry32(seed + 2);
      for (let i = 0; i < 6; i++) {
        const x = 2 + Math.floor(r() * (TILE - 6)), y = 2 + Math.floor(r() * (TILE - 6));
        const s = 2 + Math.floor(r() * 3);
        c.fillStyle = rgb(mix([150, 140, 120], [90, 80, 66], r()));
        c.fillRect(x, y, s, s);
        c.fillStyle = 'rgba(255,255,255,0.25)';
        c.fillRect(x, y, s, 1);
      }
      edgeShade(c, [140, 110, 76], [70, 48, 30]);
      break;
    }
    case 'stone': {
      const base: RGB = [120, 120, 128];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      // mortar lines
      c.strokeStyle = 'rgba(60,60,68,0.6)'; c.lineWidth = 1;
      const off = (variant % 2) * 10;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 27); c.lineTo(TILE, 27);
      c.moveTo(off, 0); c.lineTo(off, 13);
      c.moveTo(off + 20, 13); c.lineTo(off + 20, 27);
      c.moveTo(off + 10, 27); c.lineTo(off + 10, TILE);
      c.stroke();
      speckle(c, base, [[140, 140, 148], [96, 96, 104], [130, 126, 120]], 50, seed);
      edgeShade(c, [160, 160, 170], [80, 80, 88]);
      break;
    }
    case 'sand': {
      const base: RGB = [222, 200, 150];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[236, 216, 168], [200, 178, 128], [230, 206, 158]], 120, seed);
      // ripple lines
      const r = mulberry32(seed + 1);
      c.strokeStyle = 'rgba(180,156,110,0.5)'; c.lineWidth = 1;
      for (let i = 0; i < 3; i++) {
        const y = 8 + i * 12;
        c.beginPath();
        c.moveTo(0, y);
        for (let x = 0; x <= TILE; x += 4) c.lineTo(x, y + Math.sin(x * 0.4 + r() * 6) * 1.5);
        c.stroke();
      }
      edgeShade(c, [240, 222, 178], [180, 156, 108]);
      break;
    }
    case 'water': {
      const base: RGB = [54, 110, 170];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      // animated-ish shimmer (static variant)
      const r = mulberry32(seed + 3);
      for (let i = 0; i < 14; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([120, 180, 220], [40, 86, 140], r()), 0.5);
        c.fillRect(x, y, 3 + Math.floor(r() * 3), 1);
      }
      vignette(c, [20, 50, 90]);
      break;
    }
    case 'cryptFloor': {
      const base: RGB = [54, 48, 44];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(30,26,24,0.7)'; c.lineWidth = 1;
      c.strokeRect(1, 1, TILE - 2, TILE - 2);
      speckle(c, base, [[66, 58, 52], [40, 34, 30], [74, 66, 58]], 60, seed);
      // cracks
      const r = mulberry32(seed + 4);
      c.strokeStyle = 'rgba(20,16,14,0.6)';
      for (let i = 0; i < 2; i++) {
        c.beginPath();
        let x = r() * TILE, y = r() * TILE;
        c.moveTo(x, y);
        for (let s = 0; s < 4; s++) { x += (r() - 0.5) * 12; y += (r() - 0.5) * 12; c.lineTo(x, y); }
        c.stroke();
      }
      edgeShade(c, [70, 62, 56], [28, 24, 22]);
      break;
    }
    case 'cryptWall': {
      const base: RGB = [38, 34, 32];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(20,18,16,0.8)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 20); c.lineTo(TILE, 20);
      c.moveTo(13, 0); c.lineTo(13, 20);
      c.moveTo(27, 0); c.lineTo(27, 20);
      c.moveTo(7, 20); c.lineTo(7, TILE);
      c.moveTo(20, 20); c.lineTo(20, TILE);
      c.moveTo(33, 20); c.lineTo(33, TILE);
      c.stroke();
      speckle(c, base, [[50, 44, 40], [28, 24, 22]], 40, seed);
      edgeShade(c, [54, 48, 44], [20, 18, 16]);
      break;
    }
    case 'ruinsFloor': {
      const base: RGB = [96, 88, 78];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(60,54,46,0.7)'; c.lineWidth = 1;
      const off = (variant % 2) * 12;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 27); c.lineTo(TILE, 27);
      c.moveTo(off, 0); c.lineTo(off, 13);
      c.moveTo(off + 20, 13); c.lineTo(off + 20, 27);
      c.moveTo(off + 10, 27); c.lineTo(off + 10, TILE);
      c.stroke();
      // moss
      const r = mulberry32(seed + 6);
      for (let i = 0; i < 10; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([70, 110, 56], [50, 80, 40], r()), 0.6);
        c.fillRect(x, y, 2 + Math.floor(r() * 2), 2);
      }
      speckle(c, base, [[112, 104, 92], [76, 68, 58]], 40, seed);
      edgeShade(c, [120, 112, 100], [60, 54, 46]);
      break;
    }
    case 'ruinsWall': {
      const base: RGB = [108, 100, 90];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(70,64,56,0.8)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 26); c.lineTo(TILE, 26);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 0); c.lineTo(27, 13);
      c.moveTo(7, 13); c.lineTo(7, 26);
      c.moveTo(20, 13); c.lineTo(20, 26);
      c.moveTo(33, 13); c.lineTo(33, 26);
      c.moveTo(13, 26); c.lineTo(13, TILE);
      c.moveTo(27, 26); c.lineTo(27, TILE);
      c.stroke();
      speckle(c, base, [[124, 116, 104], [88, 80, 70]], 50, seed);
      edgeShade(c, [130, 122, 110], [70, 64, 56]);
      break;
    }
    case 'goldFloor': {
      const base: RGB = [150, 120, 70];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(110,86,48,0.7)'; c.lineWidth = 1;
      c.strokeRect(2, 2, TILE - 4, TILE - 4);
      c.strokeRect(6, 6, TILE - 12, TILE - 12);
      speckle(c, base, [[180, 150, 96], [120, 96, 56], [200, 168, 110]], 50, seed);
      // gold flecks
      const r = mulberry32(seed + 7);
      for (let i = 0; i < 4; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(240,210,120,0.9)';
        c.fillRect(x, y, 2, 2);
      }
      edgeShade(c, [180, 150, 96], [100, 78, 44]);
      break;
    }
    case 'goldWall': {
      const base: RGB = [130, 104, 60];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(90,70,40,0.8)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 26); c.lineTo(TILE, 26);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 0); c.lineTo(27, 13);
      c.moveTo(7, 13); c.lineTo(7, 26);
      c.moveTo(20, 13); c.lineTo(20, 26);
      c.moveTo(33, 13); c.lineTo(33, 26);
      c.moveTo(13, 26); c.lineTo(13, TILE);
      c.moveTo(27, 26); c.lineTo(27, TILE);
      c.stroke();
      speckle(c, base, [[160, 130, 80], [100, 80, 46]], 40, seed);
      edgeShade(c, [160, 130, 80], [80, 62, 36]);
      break;
    }
    case 'lava': {
      const base: RGB = [200, 70, 20];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      const r = mulberry32(seed + 8);
      for (let i = 0; i < 20; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([255, 200, 60], [160, 40, 10], r()), 0.7);
        c.fillRect(x, y, 2 + Math.floor(r() * 3), 2 + Math.floor(r() * 2));
      }
      // bright cracks
      c.strokeStyle = 'rgba(255,220,80,0.8)'; c.lineWidth = 1;
      c.beginPath();
      let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
      for (let s = 0; s < 5; s++) { x += (r() - 0.5) * 16; y += (r() - 0.5) * 16; c.lineTo(x, y); }
      c.stroke();
      vignette(c, [120, 30, 0]);
      break;
    }
    case 'ice': {
      const base: RGB = [150, 200, 230];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[180, 220, 240], [110, 170, 210], [200, 230, 245]], 70, seed);
      c.strokeStyle = 'rgba(255,255,255,0.6)'; c.lineWidth = 1;
      const r = mulberry32(seed + 9);
      for (let i = 0; i < 3; i++) {
        c.beginPath();
        let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
        for (let s = 0; s < 3; s++) { x += (r() - 0.5) * 14; y += (r() - 0.5) * 14; c.lineTo(x, y); }
        c.stroke();
      }
      edgeShade(c, [200, 230, 245], [90, 150, 190]);
      break;
    }
    case 'snow': {
      const base: RGB = [232, 238, 244];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[245, 248, 252], [210, 220, 232], [255, 255, 255]], 80, seed);
      const r = mulberry32(seed + 10);
      for (let i = 0; i < 5; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(180,200,220,0.5)';
        c.fillRect(x, y, 3, 1);
      }
      edgeShade(c, [255, 255, 255], [190, 202, 218]);
      break;
    }
    case 'swamp': {
      const base: RGB = [70, 86, 56];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[90, 104, 66], [50, 66, 40], [86, 96, 60]], 80, seed);
      // murky puddles
      const r = mulberry32(seed + 11);
      for (let i = 0; i < 3; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(40,60,50,0.7)';
        c.fillRect(x, y, 4 + Math.floor(r() * 4), 3 + Math.floor(r() * 3));
      }
      edgeShade(c, [96, 112, 72], [40, 54, 30]);
      break;
    }
    case 'mossyStone': {
      const base: RGB = [100, 104, 96];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(60,62,56,0.6)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 27); c.lineTo(TILE, 27);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 13); c.lineTo(27, 27);
      c.moveTo(7, 27); c.lineTo(7, TILE);
      c.stroke();
      // heavy moss
      const r = mulberry32(seed + 12);
      for (let i = 0; i < 18; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([70, 120, 56], [50, 90, 40], r()), 0.7);
        c.fillRect(x, y, 2 + Math.floor(r() * 2), 2);
      }
      edgeShade(c, [120, 124, 112], [60, 64, 58]);
      break;
    }
    case 'crackedStone': {
      const base: RGB = [88, 84, 80];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[104, 100, 94], [70, 66, 62]], 50, seed);
      c.strokeStyle = 'rgba(30,28,26,0.8)'; c.lineWidth = 1;
      const r = mulberry32(seed + 13);
      for (let i = 0; i < 3; i++) {
        c.beginPath();
        let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
        for (let s = 0; s < 4; s++) { x += (r() - 0.5) * 18; y += (r() - 0.5) * 18; c.lineTo(x, y); }
        c.stroke();
      }
      edgeShade(c, [110, 106, 100], [56, 52, 48]);
      break;
    }
    case 'ash': {
      const base: RGB = [70, 64, 60];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[90, 84, 78], [50, 46, 42], [110, 100, 92]], 90, seed);
      // embers
      const r = mulberry32(seed + 14);
      for (let i = 0; i < 4; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([240, 120, 40], [200, 60, 20], r()), 0.8);
        c.fillRect(x, y, 2, 2);
      }
      edgeShade(c, [96, 88, 82], [40, 36, 34]);
      break;
    }
    case 'crystal': {
      const base: RGB = [90, 80, 130];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[120, 100, 170], [60, 52, 100], [150, 130, 200]], 60, seed);
      // crystal facets
      const r = mulberry32(seed + 15);
      for (let i = 0; i < 4; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(200,180,240,0.5)';
        c.beginPath();
        c.moveTo(x, y); c.lineTo(x + 4, y - 6); c.lineTo(x + 8, y); c.closePath();
        c.fill();
      }
      edgeShade(c, [130, 110, 180], [50, 42, 86]);
      break;
    }
    case 'caveSand': {
      const base: RGB = [180, 150, 100];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[200, 170, 118], [150, 120, 76], [190, 160, 108]], 100, seed);
      // scattered small crystals (kobold hoard glints)
      const r = mulberry32(seed + 16);
      for (let i = 0; i < 3; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(220,180,80,0.7)';
        c.fillRect(x, y, 2, 2);
      }
      // subtle cave floor cracks
      c.strokeStyle = 'rgba(120,96,60,0.4)'; c.lineWidth = 1;
      c.beginPath();
      let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
      for (let s = 0; s < 3; s++) { x += (r() - 0.5) * 14; y += (r() - 0.5) * 14; c.lineTo(x, y); }
      c.stroke();
      edgeShade(c, [200, 170, 118], [130, 104, 64]);
      break;
    }
    case 'scaleFloor': {
      const base: RGB = [60, 90, 70];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      // reptilian scale pattern
      const r = mulberry32(seed + 17);
      for (let row = 0; row < 5; row++) {
        for (let col = 0; col < 5; col++) {
          const x = col * 8 + (row % 2) * 4;
          const y = row * 8;
          const sc = mix([80, 120, 86], [40, 70, 52], r());
          c.fillStyle = rgb(sc, 0.85);
          c.beginPath();
          c.arc(x + 4, y + 4, 4, 0, Math.PI, false);
          c.fill();
          c.strokeStyle = 'rgba(30,50,36,0.5)'; c.lineWidth = 1;
          c.stroke();
        }
      }
      // murky water patches
      for (let i = 0; i < 2; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(40,70,60,0.6)';
        c.fillRect(x, y, 5, 4);
      }
      edgeShade(c, [90, 130, 96], [30, 56, 40]);
      break;
    }
    case 'scaleWall': {
      const base: RGB = [50, 78, 60];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      const r = mulberry32(seed + 18);
      for (let row = 0; row < 5; row++) {
        for (let col = 0; col < 5; col++) {
          const x = col * 8 + (row % 2) * 4;
          const y = row * 8;
          const sc = mix([70, 104, 80], [34, 60, 46], r());
          c.fillStyle = rgb(sc, 0.9);
          c.beginPath();
          c.arc(x + 4, y + 4, 4, 0, Math.PI, false);
          c.fill();
          c.strokeStyle = 'rgba(20,40,30,0.6)'; c.lineWidth = 1;
          c.stroke();
        }
      }
      edgeShade(c, [80, 116, 90], [24, 46, 36]);
      break;
    }
    case 'frozenFloor': {
      const base: RGB = [170, 200, 220];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[200, 225, 240], [130, 170, 200], [220, 240, 250]], 70, seed);
      // ice cracks
      const r = mulberry32(seed + 19);
      c.strokeStyle = 'rgba(100,150,190,0.6)'; c.lineWidth = 1;
      for (let i = 0; i < 3; i++) {
        c.beginPath();
        let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
        for (let s = 0; s < 3; s++) { x += (r() - 0.5) * 16; y += (r() - 0.5) * 16; c.lineTo(x, y); }
        c.stroke();
      }
      // frost crystals
      for (let i = 0; i < 4; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(255,255,255,0.6)';
        c.fillRect(x, y, 2, 2);
      }
      edgeShade(c, [210, 230, 245], [110, 150, 180]);
      break;
    }
    case 'frozenWall': {
      const base: RGB = [140, 175, 200];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(80,120,160,0.7)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 27); c.lineTo(TILE, 27);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 0); c.lineTo(27, 13);
      c.moveTo(7, 13); c.lineTo(7, 27);
      c.moveTo(20, 13); c.lineTo(20, 27);
      c.moveTo(33, 13); c.lineTo(33, 27);
      c.moveTo(13, 27); c.lineTo(13, TILE);
      c.moveTo(27, 27); c.lineTo(27, TILE);
      c.stroke();
      // ice sheen
      const r = mulberry32(seed + 20);
      for (let i = 0; i < 6; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(255,255,255,0.4)';
        c.fillRect(x, y, 3, 1);
      }
      edgeShade(c, [170, 200, 220], [80, 120, 160]);
      break;
    }
    case 'webFloor': {
      const base: RGB = [40, 36, 44];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[54, 48, 58], [30, 26, 34], [60, 54, 64]], 50, seed);
      // cobweb pattern
      c.strokeStyle = 'rgba(200,200,210,0.25)'; c.lineWidth = 1;
      const cx = TILE / 2, cy = TILE / 2;
      for (let a = 0; a < 8; a++) {
        const ang = (a / 8) * Math.PI * 2;
        c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(ang) * 20, cy + Math.sin(ang) * 20); c.stroke();
      }
      for (let r = 4; r < 20; r += 5) {
        c.beginPath(); c.arc(cx, cy, r, 0, Math.PI * 2); c.stroke();
      }
      edgeShade(c, [56, 50, 60], [20, 18, 24]);
      break;
    }
    case 'webWall': {
      const base: RGB = [32, 28, 36];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(180,180,190,0.2)'; c.lineWidth = 1;
      const r = mulberry32(seed + 21);
      for (let i = 0; i < 5; i++) {
        const x1 = r() * TILE, y1 = r() * TILE;
        const x2 = r() * TILE, y2 = r() * TILE;
        c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.stroke();
      }
      speckle(c, base, [[44, 38, 48], [24, 20, 28]], 40, seed);
      edgeShade(c, [48, 42, 52], [16, 14, 20]);
      break;
    }
    case 'coralFloor': {
      const base: RGB = [100, 140, 150];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[130, 170, 180], [70, 110, 120], [150, 180, 190]], 80, seed);
      // coral branches
      const r = mulberry32(seed + 22);
      for (let i = 0; i < 4; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([220, 120, 130], [180, 90, 110], r()), 0.7);
        c.fillRect(x, y, 2, 4 + Math.floor(r() * 3));
        c.fillRect(x - 2, y + 2, 2, 2);
        c.fillRect(x + 2, y + 2, 2, 2);
      }
      edgeShade(c, [130, 170, 180], [60, 100, 110]);
      break;
    }
    case 'coralWall': {
      const base: RGB = [80, 120, 130];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(50,90,100,0.7)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 26); c.lineTo(TILE, 26);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 0); c.lineTo(27, 13);
      c.moveTo(7, 13); c.lineTo(7, 26);
      c.moveTo(20, 13); c.lineTo(20, 26);
      c.moveTo(33, 13); c.lineTo(33, 26);
      c.moveTo(13, 26); c.lineTo(13, TILE);
      c.moveTo(27, 26); c.lineTo(27, TILE);
      c.stroke();
      const r = mulberry32(seed + 23);
      for (let i = 0; i < 3; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(220,120,130,0.6)';
        c.fillRect(x, y, 3, 3);
      }
      edgeShade(c, [110, 150, 160], [50, 90, 100]);
      break;
    }
    case 'volcanicFloor': {
      const base: RGB = [50, 40, 38];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[70, 56, 52], [34, 28, 26], [80, 64, 58]], 70, seed);
      // lava veins
      const r = mulberry32(seed + 24);
      c.strokeStyle = 'rgba(255,120,30,0.7)'; c.lineWidth = 1;
      for (let i = 0; i < 2; i++) {
        c.beginPath();
        let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
        for (let s = 0; s < 4; s++) { x += (r() - 0.5) * 14; y += (r() - 0.5) * 14; c.lineTo(x, y); }
        c.stroke();
      }
      // embers
      for (let i = 0; i < 3; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(255,160,40,0.8)';
        c.fillRect(x, y, 2, 2);
      }
      edgeShade(c, [80, 64, 58], [24, 20, 18]);
      break;
    }
    case 'volcanicWall': {
      const base: RGB = [42, 34, 32];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(20,16,14,0.8)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 27); c.lineTo(TILE, 27);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 0); c.lineTo(27, 13);
      c.moveTo(7, 13); c.lineTo(7, 27);
      c.moveTo(20, 13); c.lineTo(20, 27);
      c.moveTo(33, 13); c.lineTo(33, 27);
      c.moveTo(13, 27); c.lineTo(13, TILE);
      c.moveTo(27, 27); c.lineTo(27, TILE);
      c.stroke();
      // glowing cracks
      const r = mulberry32(seed + 25);
      c.strokeStyle = 'rgba(255,100,20,0.6)';
      for (let i = 0; i < 2; i++) {
        c.beginPath();
        let x = r() * TILE, y = r() * TILE; c.moveTo(x, y);
        for (let s = 0; s < 3; s++) { x += (r() - 0.5) * 16; y += (r() - 0.5) * 16; c.lineTo(x, y); }
        c.stroke();
      }
      edgeShade(c, [64, 52, 48], [18, 14, 12]);
      break;
    }
    case 'mushroomFloor': {
      const base: RGB = [80, 70, 60];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      speckle(c, base, [[100, 88, 76], [60, 52, 44], [110, 96, 84]], 70, seed);
      // mushroom spots
      const r = mulberry32(seed + 26);
      for (let i = 0; i < 4; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        const cap: RGB = r() > 0.5 ? [180, 60, 80] : [120, 80, 160];
        c.fillStyle = rgb(cap, 0.8);
        c.fillRect(x, y, 4, 3);
        c.fillStyle = 'rgba(255,255,255,0.5)';
        c.fillRect(x, y, 4, 1);
      }
      // spores
      for (let i = 0; i < 6; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = 'rgba(200,190,170,0.4)';
        c.fillRect(x, y, 1, 1);
      }
      edgeShade(c, [110, 96, 84], [44, 38, 32]);
      break;
    }
    case 'mushroomWall': {
      const base: RGB = [60, 52, 44];
      c.fillStyle = rgb(base); c.fillRect(0, 0, TILE, TILE);
      c.strokeStyle = 'rgba(30,24,20,0.8)'; c.lineWidth = 1;
      c.beginPath();
      c.moveTo(0, 13); c.lineTo(TILE, 13);
      c.moveTo(0, 27); c.lineTo(TILE, 27);
      c.moveTo(13, 0); c.lineTo(13, 13);
      c.moveTo(27, 0); c.lineTo(27, 13);
      c.moveTo(7, 13); c.lineTo(7, 27);
      c.moveTo(20, 13); c.lineTo(20, 27);
      c.moveTo(33, 13); c.lineTo(33, 27);
      c.moveTo(13, 27); c.lineTo(13, TILE);
      c.moveTo(27, 27); c.lineTo(27, TILE);
      c.stroke();
      // fungal growth
      const r = mulberry32(seed + 27);
      for (let i = 0; i < 5; i++) {
        const x = Math.floor(r() * TILE), y = Math.floor(r() * TILE);
        c.fillStyle = rgb(mix([160, 80, 100], [100, 60, 140], r()), 0.7);
        c.fillRect(x, y, 3, 2);
      }
      edgeShade(c, [84, 72, 62], [32, 26, 22]);
      break;
    }
  }

  cache.set(key, cv);
  return cv;
}

export function drawTile(
  ctx: CanvasRenderingContext2D,
  kind: TileKind,
  sx: number, sy: number,
  tx: number, ty: number,
) {
  const variant = Math.floor(hash3(tx, ty, kind.charCodeAt(0)) * 8);
  const cv = renderTile(kind, variant);
  ctx.drawImage(cv, sx, sy, TILE + 1, TILE + 1);
}

export const TILE_SIZE = TILE;
