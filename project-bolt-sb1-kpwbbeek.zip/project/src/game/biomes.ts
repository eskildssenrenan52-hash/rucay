// Biome definitions, world generation with random distribution + transitions,
// and the multi-floor "stairwell" system (each biome has 4 stacked floors).

import { TileKind } from './tiles';

export interface BiomeDef {
  id: string;
  name: string;
  theme: string; // monster family
  level: number; // base enemy level (higher = further from spawn)
  floor: TileKind; // walkable ground
  wall: TileKind; // walls / obstacles
  accent: TileKind; // decorative patches
  stairDown: TileKind; // tile at the stairwell entrance
  monsterKeys: string[]; // which monster defs spawn here
  monsterDensity: number;
  ambient: string; // overlay tint
  order: number; // distance tier 1..5
}

// 12 biomes ordered weakest -> strongest. "order" drives placement distance.
export const BIOMES: BiomeDef[] = [
  {
    id: 'sewers', name: 'Esgotos', theme: 'Ratos', level: 1, order: 1,
    floor: 'cryptFloor', wall: 'cryptWall', accent: 'swamp', stairDown: 'mossyStone',
    monsterKeys: ['rat', 'slime', 'goblin'], monsterDensity: 0.10,
    ambient: 'rgba(40,60,50,0.10)',
  },
  {
    id: 'forest', name: 'Floresta Sombria', theme: 'Lobos', level: 3, order: 2,
    floor: 'grass', wall: 'mossyStone', accent: 'dirt', stairDown: 'stone',
    monsterKeys: ['wolf', 'goblin', 'goblinwar'], monsterDensity: 0.09,
    ambient: 'rgba(30,60,30,0.08)',
  },
  {
    id: 'koboldcave', name: 'Caverna dos Kobolds', theme: 'Kobolds', level: 5, order: 3,
    floor: 'caveSand', wall: 'crackedStone', accent: 'crystal', stairDown: 'stone',
    monsterKeys: ['kobold', 'koboldwar', 'slime'], monsterDensity: 0.11,
    ambient: 'rgba(80,50,30,0.10)',
  },
  {
    id: 'ruins', name: 'Ruínas Antigas', theme: 'Mortos-Vivos', level: 7, order: 4,
    floor: 'ruinsFloor', wall: 'ruinsWall', accent: 'crackedStone', stairDown: 'stone',
    monsterKeys: ['skeleton', 'zombie', 'skeletonwar'], monsterDensity: 0.10,
    ambient: 'rgba(60,50,40,0.10)',
  },
  {
    id: 'lizardmarsh', name: 'Pântano dos Lizard Men', theme: 'Lizard Men', level: 10, order: 5,
    floor: 'scaleFloor', wall: 'scaleWall', accent: 'water', stairDown: 'mossyStone',
    monsterKeys: ['lizardman', 'lizardwar', 'wolf'], monsterDensity: 0.09,
    ambient: 'rgba(40,70,50,0.12)',
  },
  {
    id: 'frostcavern', name: 'Caverna Gelada', theme: 'Aranhas do Gelo', level: 12, order: 6,
    floor: 'frozenFloor', wall: 'frozenWall', accent: 'ice', stairDown: 'frozenWall',
    monsterKeys: ['icespider', 'frostwolf', 'skeleton'], monsterDensity: 0.09,
    ambient: 'rgba(150,200,230,0.10)',
  },
  {
    id: 'spiderlair', name: 'Covil das Aranhas', theme: 'Aranhas Gigantes', level: 14, order: 7,
    floor: 'webFloor', wall: 'webWall', accent: 'cryptFloor', stairDown: 'webWall',
    monsterKeys: ['giantspider', 'poisonspider', 'slime'], monsterDensity: 0.10,
    ambient: 'rgba(50,40,60,0.12)',
  },
  {
    id: 'golemhall', name: 'Salão dos Golems', theme: 'Golems', level: 16, order: 8,
    floor: 'stone', wall: 'crackedStone', accent: 'mossyStone', stairDown: 'goldFloor',
    monsterKeys: ['ogre', 'skeletonwar', 'goblinwar'], monsterDensity: 0.08,
    ambient: 'rgba(50,50,60,0.12)',
  },
  {
    id: 'coralreef', name: 'Recife de Coral', theme: 'Tritões', level: 19, order: 9,
    floor: 'coralFloor', wall: 'coralWall', accent: 'water', stairDown: 'coralWall',
    monsterKeys: ['triton', 'merfolk', 'lizardwar'], monsterDensity: 0.08,
    ambient: 'rgba(40,120,140,0.12)',
  },
  {
    id: 'volcanic', name: 'Câmara Vulcânica', theme: 'Elementais de Fogo', level: 22, order: 10,
    floor: 'volcanicFloor', wall: 'volcanicWall', accent: 'lava', stairDown: 'volcanicWall',
    monsterKeys: ['firelemental', 'lavabeast', 'ogre'], monsterDensity: 0.07,
    ambient: 'rgba(180,60,20,0.14)',
  },
  {
    id: 'mushroomgrove', name: 'Bosque dos Cogumelos', theme: 'Cogumelos Vivos', level: 25, order: 11,
    floor: 'mushroomFloor', wall: 'mushroomWall', accent: 'swamp', stairDown: 'mushroomWall',
    monsterKeys: ['mushroomman', 'sporebeast', 'poisonspider'], monsterDensity: 0.08,
    ambient: 'rgba(100,60,80,0.12)',
  },
  {
    id: 'dragonlair', name: 'Covil dos Dragões', theme: 'Dragões', level: 30, order: 12,
    floor: 'ash', wall: 'crackedStone', accent: 'lava', stairDown: 'crystal',
    monsterKeys: ['ogre', 'skeletonwar', 'wolf'], monsterDensity: 0.07,
    ambient: 'rgba(120,30,10,0.12)',
  },
];

export const BIOME_BY_ID = new Map(BIOMES.map(b => [b.id, b]));

// Each biome has 4 floors. Floor 0 = surface world. Floors 1-3 are reached via
// stairwells: each floor contains a stair DOWN to the next, and the deepest has
// a stair back UP. Enemy level scales per floor.
export const FLOORS_PER_BIOME = 4;

export interface Cell {
  biome: string;
  floor: TileKind;
  wall: boolean;
  decor?: 'stairDown' | 'stairUp' | 'torch' | 'rock' | 'crystal' | 'pillar' | 'bones';
  stairTo?: { biome: string; floor: number }; // where this stair leads
  isSpawn?: boolean;
}

export interface FloorMap {
  biome: string;
  floor: number; // 0..3
  w: number;
  h: number;
  cells: Cell[][]; // [y][x]
  stairDownPos: { x: number; y: number } | null;
  stairUpPos: { x: number; y: number } | null;
  spawnPos: { x: number; y: number };
}

// ---- World layout: a large grid of biome regions on the surface (floor 0) ----
// We use a big surface map and assign each region to a biome by distance tiers
// so weaker biomes are near spawn and stronger ones further out, but with
// randomized boundaries and transition zones.

const SURFACE_W = 200;
const SURFACE_H = 150;

function seededRand(seed: number) {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6D2B79F5) | 0;
    let t = Math.imul(s ^ (s >>> 15), 1 | s);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Voronoi-ish biome centers, ordered by distance from map center so order tiers
// emerge naturally, but centers jittered for randomness.
function biomeCenters(seed: number) {
  const r = seededRand(seed);
  const cx = SURFACE_W / 2, cy = SURFACE_H / 2;
  // place one center per biome, at increasing radius, random angle
  const centers: { x: number; y: number; biome: BiomeDef }[] = [];
  BIOMES.forEach((b, i) => {
    const radius = 18 + i * 20 + r() * 12;
    const ang = r() * Math.PI * 2;
    centers.push({ x: cx + Math.cos(ang) * radius, y: cy + Math.sin(ang) * radius, biome: b });
  });
  return centers;
}

// transition: blend floor tile kinds near borders so adjacent biomes fade into
// each other. We pick the floor of the nearest biome but, within a band, mix
// in the accent of the second-nearest.
function pickFloor(
  x: number, y: number,
  centers: { x: number; y: number; biome: BiomeDef }[],
): { floor: TileKind; biome: BiomeDef; transition: boolean } {
  const sorted = centers.map(c => ({ c, d: Math.hypot(c.x - x, c.y - y) }))
    .sort((a, b) => a.d - b.d);
  const near = sorted[0];
  const next = sorted[1];
  // transition band: when second-nearest is close to nearest
  const ratio = next.d / (near.d + 0.01);
  if (ratio < 1.25 && Math.random() < 0.5) {
    return { floor: next.c.biome.accent, biome: near.c.biome, transition: true };
  }
  return { floor: near.c.biome.floor, biome: near.c.biome, transition: false };
}

let surfaceBuilt: { centers: ReturnType<typeof biomeCenters>; cells: Cell[][] } | null = null;

function buildSurface(seed: number) {
  if (surfaceBuilt) return surfaceBuilt;
  const centers = biomeCenters(seed);
  const cells: Cell[][] = [];
  const r = seededRand(seed + 99);
  for (let y = 0; y < SURFACE_H; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < SURFACE_W; x++) {
      const { floor, biome, transition } = pickFloor(x, y, centers);
      const wall = !transition && r() < 0.06;
      let decor: Cell['decor'] | undefined;
      if (!wall) {
        const dr = r();
        if (dr < 0.02) decor = 'rock';
        else if (dr < 0.03) decor = 'torch';
        else if (dr < 0.035) decor = 'pillar';
      }
      row.push({ biome: biome.id, floor, wall, decor });
    }
    cells.push(row);
  }
  // spawn at center
  const sx = Math.floor(SURFACE_W / 2), sy = Math.floor(SURFACE_H / 2);
  cells[sy][sx].wall = false; cells[sy][sx].decor = undefined; cells[sy][sx].isSpawn = true;
  // clear a larger safe zone around spawn
  for (let dy = -5; dy <= 5; dy++)
    for (let dx = -5; dx <= 5; dx++) {
      const yy = sy + dy, xx = sx + dx;
      if (yy >= 0 && yy < SURFACE_H && xx >= 0 && xx < SURFACE_W) {
        cells[yy][xx].wall = false;
        if (Math.abs(dx) + Math.abs(dy) > 0) cells[yy][xx].decor = undefined;
      }
    }
  // place one stair-down per biome region on the surface, near each center
  for (const c of centers) {
    const tx = Math.round(c.x), ty = Math.round(c.y);
    if (tx === sx && ty === sy) continue;
    // find a nearby non-wall cell
    for (let rad = 0; rad < 15; rad++) {
      let placed = false;
      for (let a = 0; a < 8; a++) {
        const ax = tx + Math.round(Math.cos(a / 8 * Math.PI * 2) * rad);
        const ay = ty + Math.round(Math.sin(a / 8 * Math.PI * 2) * rad);
        if (ax >= 0 && ax < SURFACE_W && ay >= 0 && ay < SURFACE_H && !cells[ay][ax].wall) {
          cells[ay][ax].decor = 'stairDown';
          cells[ay][ax].stairTo = { biome: c.biome.id, floor: 1 };
          placed = true; break;
        }
      }
      if (placed) break;
    }
  }
  surfaceBuilt = { centers, cells };
  return surfaceBuilt;
}

// ---- Interior floors (1..3) of a biome: a room with a stair down + stair up ----
const interiorCache = new Map<string, FloorMap>();

function buildInterior(biomeId: string, floor: number, seed: number): FloorMap {
  const key = `${biomeId}:${floor}`;
  const cached = interiorCache.get(key);
  if (cached) return cached;
  const biome = BIOME_BY_ID.get(biomeId)!;
  const W = 80, H = 60;
  const r = seededRand(seed + floor * 31 + biome.order * 7);
  const cells: Cell[][] = [];
  for (let y = 0; y < H; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < W; x++) {
      const border = x === 0 || y === 0 || x === W - 1 || y === H - 1;
      const wall = border || r() < 0.08;
      let decor: Cell['decor'] | undefined;
      if (!wall) {
        const dr = r();
        if (dr < 0.03) decor = 'torch';
        else if (dr < 0.06) decor = 'pillar';
        else if (dr < 0.08) decor = 'rock';
        else if (dr < 0.085 && floor >= 2) decor = 'bones';
        else if (dr < 0.09 && biome.id === 'dragonlair') decor = 'crystal';
      }
      row.push({ biome: biomeId, floor: biome.floor, wall, decor });
    }
    cells.push(row);
  }
  // spawn = stair-up position (where you arrive from floor above)
  const upX = Math.floor(W / 2), upY = Math.floor(H / 2);
  cells[upY][upX].wall = false; cells[upY][upX].decor = 'stairUp';
  cells[upY][upX].stairTo = floor > 1
    ? { biome: biomeId, floor: floor - 1 }
    : { biome: biomeId, floor: 0 };
  // clear around up (larger safe zone for bigger maps)
  for (let dy = -3; dy <= 3; dy++)
    for (let dx = -3; dx <= 3; dx++) {
      const yy = upY + dy, xx = upX + dx;
      if (yy > 0 && yy < H - 1 && xx > 0 && xx < W - 1) { cells[yy][xx].wall = false; cells[yy][xx].decor = undefined; }
    }
  // stair-down placed far from up, leads to next floor (or loops back if deepest)
  let downX = 0, downY = 0, best = -1;
  for (let y = 1; y < H - 1; y++)
    for (let x = 1; x < W - 1; x++) {
      if (cells[y][x].wall) continue;
      const d = Math.hypot(x - upX, y - upY);
      if (d > best) { best = d; downX = x; downY = y; }
    }
  if (floor < FLOORS_PER_BIOME - 1) {
    cells[downY][downX].decor = 'stairDown';
    cells[downY][downX].stairTo = { biome: biomeId, floor: floor + 1 };
  } else {
    // deepest floor: stair loops back up
    cells[downY][downX].decor = 'stairUp';
    cells[downY][downX].stairTo = { biome: biomeId, floor: floor - 1 };
  }
  const map: FloorMap = {
    biome: biomeId, floor, w: W, h: H, cells,
    stairDownPos: { x: downX, y: downY },
    stairUpPos: { x: upX, y: upY },
    spawnPos: { x: upX, y: upY },
  };
  interiorCache.set(key, map);
  return map;
}

export interface WorldLoc {
  biome: string;
  floor: number;
}

export function getFloorMap(loc: WorldLoc, seed: number): FloorMap {
  if (loc.floor === 0) {
    const s = buildSurface(seed);
    return {
      biome: loc.biome, floor: 0, w: SURFACE_W, h: SURFACE_H, cells: s.cells,
      stairDownPos: null, stairUpPos: null,
      spawnPos: { x: Math.floor(SURFACE_W / 2), y: Math.floor(SURFACE_H / 2) },
    };
  }
  return buildInterior(loc.biome, loc.floor, seed);
}

export function surfaceSpawn(): { x: number; y: number } {
  return { x: Math.floor(SURFACE_W / 2), y: Math.floor(SURFACE_H / 2) };
}

export function biomeAt(loc: WorldLoc): BiomeDef {
  return BIOME_BY_ID.get(loc.biome)!;
}

// enemy level for a given location: base biome level + floor bonus
export function enemyLevel(loc: WorldLoc): number {
  const b = BIOME_BY_ID.get(loc.biome)!;
  return b.level + loc.floor * 2;
}

export { SURFACE_W, SURFACE_H };
