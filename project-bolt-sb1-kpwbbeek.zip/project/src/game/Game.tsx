import { useEffect, useRef, useState, useCallback } from 'react';
import { TILE_SIZE, drawTile, TileKind } from './tiles';
import {
  BIOME_BY_ID, getFloorMap, surfaceSpawn, biomeAt, enemyLevel,
  WorldLoc, FloorMap, Cell,
} from './biomes';
import { Monster, spawnForBiome, maxMonstersFor } from './monsters';
import {
  CLASS_DEFS, AttrMap, deriveStats, DerivedStats,
  classXpNext, playerXpNext,
} from './attributes';
import {
  StatusModal, InventoryModal, InvItem, WorldMapModal, EquipmentModal, EquipSlot,
  SkillsModal, BestiaryModal, QuestsModal, Quest, SettingsModal,
} from './modals';

const ASSET = (n: string) => `assets/${n}-default-000.png`;
function loadImg(name: string) {
  const i = new Image();
  i.src = ASSET(name);
  return i;
}

const IMG: Record<string, HTMLImageElement> = {
  shadow: loadImg('shadow'),
  box: loadImg('caixa'),
  torch: loadImg('tocha1'),
  esmeralda: loadImg('esmeralda'),
  potHp: loadImg('lifepotionpequena'),
  potHpMed: loadImg('lifepotionmedia'),
  potMp: loadImg('manapotionpequena'),
  sword: loadImg('espadadeacolv275'),
  shield: loadImg('escudodeacolv75'),
  bow: loadImg('arcodeferrolv75'),
  staff: loadImg('cajadomisticolv175'),
  merchantIdle: loadImg('comercianteagaichado'),
  guerreiroIdle: loadImg('cavaleiroagaichado'),
  guerreiroMove: loadImg('cavaleirolevantado'),
  arqueiroIdle: loadImg('arqueiroagaichado'),
  arqueiroMove: loadImg('arqueirolevantado'),
  magoIdle: loadImg('magoagaichado'),
  magoMove: loadImg('magolevantado'),
  goblinIdle: loadImg('goblinagaichado'),
  goblinMove: loadImg('goblinlevantado'),
  goblinWarMove: loadImg('goblinguerreirolevantado'),
  skeletonIdle: loadImg('esqueletoagaichado'),
  skeletonMove: loadImg('esqueletolevantado'),
  skeletonWarMove: loadImg('esqueletoguerreirolevantado'),
  wolfMove: loadImg('loboguerreirolevantado'),
  wolfIdle: loadImg('loboguerreiroagaichado'),
  zombieMove: loadImg('zumbilevantado'),
  zombieIdle: loadImg('zumbiagaichado'),
  slimeMove: loadImg('slimelevantado'),
  slimeIdle: loadImg('slimeagaichado'),
  ratMove: loadImg('ratolevantado'),
  ratIdle: loadImg('ratoagaichado'),
  ogreMove: loadImg('ogrolevantado'),
  ogreIdle: loadImg('ogroagaichado'),
};

interface Player {
  x: number; y: number; dir: number; moving: boolean;
  hp: number; mp: number; gold: number;
  inv: { hp: number; mp: number };
  attackCD: number; alive: boolean; classKey: string | null;
  attrs: AttrMap; statPoints: number;
  classLevel: number; classXp: number;
  playerLevel: number; playerXp: number;
  kills: Record<string, number>;
  questsDone: number;
}

interface FloatText { x: number; y: number; text: string; color: string; life: number; }
interface Projectile { x: number; y: number; tx: number; ty: number; target: Monster | null; speed: number; color: string; done: boolean; crit: boolean; }

const SEED = 20260630;

type ModalType = 'status' | 'inventory' | 'map' | 'equipment' | 'skills' | 'bestiary' | 'quests' | 'settings' | 'shop' | null;

export default function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [classChosen, setClassChosen] = useState(false);
  const [dead, setDead] = useState(false);
  const [modal, setModal] = useState<ModalType>(null);
  const [hud, setHud] = useState({
    hp: 100, maxHp: 100, mp: 50, maxMp: 50,
    playerXp: 0, playerXpNext: 65, playerLevel: 1,
    classXp: 0, classXpNext: 50, classLevel: 1,
    gold: 40, hpPot: 3, mpPot: 3, className: '', statPoints: 0,
  });
  const [biomeLabel, setBiomeLabel] = useState('Esgotos — Andar 0');
  const [banner, setBanner] = useState<{ text: string; color: string } | null>(null);
  const [logs, setLogs] = useState<string[]>([]);
  const [soundOn, setSoundOn] = useState(true);
  const [joystick, setJoystick] = useState({ active: false, dx: 0, dy: 0 });
  const [quests, setQuests] = useState<Quest[]>([
    { id: 'q1', name: 'Exterminador de Ratos', desc: 'Derrote 10 ratos nos Esgotos.', progress: 0, total: 10, reward: '50 ouro' },
    { id: 'q2', name: 'Caçador de Lobos', desc: 'Derrote 8 lobos na Floresta.', progress: 0, total: 8, reward: '80 ouro' },
    { id: 'q3', name: 'Profundezas', desc: 'Alcance o 3º andar de qualquer bioma.', progress: 0, total: 1, reward: '100 ouro' },
  ]);

  const stateRef = useRef({
    player: {
      x: surfaceSpawn().x * TILE_SIZE + TILE_SIZE / 2,
      y: surfaceSpawn().y * TILE_SIZE + TILE_SIZE / 2,
      dir: 1, moving: false,
      hp: 100, mp: 50, gold: 40,
      inv: { hp: 3, mp: 3 },
      attackCD: 0, alive: true, classKey: null as string | null,
      attrs: {} as AttrMap, statPoints: 0,
      classLevel: 1, classXp: 0,
      playerLevel: 1, playerXp: 0,
      kills: {} as Record<string, number>,
      questsDone: 0,
    } as Player,
    monsters: [] as Monster[],
    floats: [] as FloatText[],
    projectiles: [] as Projectile[],
    camX: 0, camY: 0, shake: 0,
    keys: {} as Record<string, boolean>,
    joyVec: { dx: 0, dy: 0 },
    loc: { biome: 'sewers', floor: 0 } as WorldLoc,
    floorMap: null as FloorMap | null,
    merchantPos: { tx: 0, ty: 0 },
    logQueue: [] as string[],
    transitionFlash: 0,
    maxOrderReached: 1,
    deepestFloor: 0,
    attackTarget: null as Monster | null,
    autoAttack: false,
  });

  const log = useCallback((msg: string) => { stateRef.current.logQueue.push(msg); }, []);
  const showBanner = useCallback((text: string, color: string) => {
    setBanner({ text, color });
    setTimeout(() => setBanner(null), 1400);
  }, []);

  const getDerived = useCallback((): DerivedStats | null => {
    const p = stateRef.current.player;
    if (!p.classKey) return null;
    return deriveStats(CLASS_DEFS[p.classKey], p.attrs, p.classLevel, p.playerLevel);
  }, []);

  const syncHud = useCallback(() => {
    const p = stateRef.current.player;
    const d = getDerived();
    if (!d) return;
    setHud({
      hp: Math.ceil(p.hp), maxHp: d.maxHp, mp: Math.ceil(p.mp), maxMp: d.maxMp,
      playerXp: p.playerXp, playerXpNext: playerXpNext(p.playerLevel), playerLevel: p.playerLevel,
      classXp: p.classXp, classXpNext: classXpNext(p.classLevel), classLevel: p.classLevel,
      gold: p.gold, hpPot: p.inv.hp, mpPot: p.inv.mp,
      className: p.classKey ? CLASS_DEFS[p.classKey].name : '',
      statPoints: p.statPoints,
    });
  }, [getDerived]);

  const isBlocked = useCallback((tx: number, ty: number) => {
    const fm = stateRef.current.floorMap;
    if (!fm) return true;
    if (tx < 0 || ty < 0 || tx >= fm.w || ty >= fm.h) return true;
    return fm.cells[ty][tx].wall;
  }, []);

  const loadFloor = useCallback((newLoc: WorldLoc) => {
    const fm = getFloorMap(newLoc, SEED);
    stateRef.current.floorMap = fm;
    stateRef.current.loc = newLoc;
    const b = biomeAt(newLoc);
    setBiomeLabel(`${b.name} — Andar ${newLoc.floor}`);
    stateRef.current.maxOrderReached = Math.max(stateRef.current.maxOrderReached, b.order);
    stateRef.current.deepestFloor = Math.max(stateRef.current.deepestFloor, newLoc.floor);

    let px: number, py: number;
    if (newLoc.floor === 0) {
      const sp = surfaceSpawn();
      px = sp.x * TILE_SIZE + TILE_SIZE / 2;
      py = sp.y * TILE_SIZE + TILE_SIZE / 2;
    } else {
      px = fm.spawnPos.x * TILE_SIZE + TILE_SIZE / 2;
      py = fm.spawnPos.y * TILE_SIZE + TILE_SIZE / 2;
    }
    const p = stateRef.current.player;
    p.x = px; p.y = py;

    if (newLoc.floor === 0) {
      const sp = surfaceSpawn();
      const mtx = sp.x + 3, mty = sp.y;
      if (mtx < fm.w && mty < fm.h) fm.cells[mty][mtx].wall = false;
      stateRef.current.merchantPos = { tx: mtx, ty: mty };
    } else {
      stateRef.current.merchantPos = { tx: -10, ty: -10 };
    }

    const biome = biomeAt(newLoc);
    const count = Math.min(maxMonstersFor(biome), 60);
    stateRef.current.monsters = spawnForBiome(newLoc, fm.w, fm.h, TILE_SIZE, isBlocked, SEED + newLoc.floor * 17, count);
    stateRef.current.transitionFlash = 30;
    log(`Você entrou em ${b.name} (Andar ${newLoc.floor}). Nível dos inimigos: ${enemyLevel(newLoc)}.`);

    // quest progress: deepest floor
    if (newLoc.floor >= 3) {
      setQuests(prev => prev.map(q => q.id === 'q3' ? { ...q, progress: 1 } : q));
    }
  }, [isBlocked, log]);

  const setClass = useCallback((key: string) => {
    const c = CLASS_DEFS[key];
    const p = stateRef.current.player;
    p.classKey = key;
    p.attrs = { ...c.baseAttrs };
    p.statPoints = 0;
    p.classLevel = 1; p.classXp = 0;
    p.playerLevel = 1; p.playerXp = 0;
    const d = deriveStats(c, p.attrs, 1, 1);
    p.hp = d.maxHp; p.mp = d.maxMp;
    p.gold = 40;
    p.inv = { hp: 3, mp: 3 };
    setClassChosen(true);
    log(`Você iniciou a jornada como ${c.name}.`);
    syncHud();
  }, [log, syncHud]);

  const addAttr = useCallback((key: string) => {
    const p = stateRef.current.player;
    if (p.statPoints <= 0) return;
    p.attrs[key] = (p.attrs[key] || 0) + 1;
    p.statPoints--;
    const d = getDerived();
    if (d) {
      if (p.hp > d.maxHp) p.hp = d.maxHp;
      if (p.mp > d.maxMp) p.mp = d.maxMp;
    }
    syncHud();
  }, [getDerived, syncHud]);

  const usePotion = useCallback((type: 'hp' | 'mp') => {
    const p = stateRef.current.player;
    if (!p.alive) return;
    if (p.inv[type] <= 0) { log('Você não tem essa poção.'); return; }
    p.inv[type]--;
    const d = getDerived();
    if (type === 'hp') { p.hp = Math.min(d!.maxHp, p.hp + 40); log('Poção de vida usada (+40 HP).'); }
    else { p.mp = Math.min(d!.maxMp, p.mp + 30); log('Poção de mana usada (+30 MP).'); }
    syncHud();
  }, [getDerived, log, syncHud]);

  const buyPotion = useCallback((type: 'hp' | 'mp') => {
    const p = stateRef.current.player;
    const d = getDerived()!;
    const cost = Math.round(15 * (1 - d.shopDiscount));
    if (p.gold >= cost) {
      p.gold -= cost;
      p.inv[type]++;
      log(`Comprou 1 poção de ${type === 'hp' ? 'vida' : 'mana'} (${cost}g).`);
      syncHud();
    } else log('Ouro insuficiente.');
  }, [getDerived, log, syncHud]);

  const revive = useCallback(() => {
    const p = stateRef.current.player;
    p.alive = true;
    const d = getDerived()!;
    p.hp = d.maxHp; p.mp = d.maxMp;
    setDead(false);
    loadFloor({ biome: 'sewers', floor: 0 });
    log('Você renasceu na superfície.');
    syncHud();
  }, [getDerived, loadFloor, log, syncHud]);

  const resetGame = useCallback(() => {
    setModal(null);
    setClassChosen(false);
    setDead(false);
    stateRef.current.player = {
      x: surfaceSpawn().x * TILE_SIZE + TILE_SIZE / 2,
      y: surfaceSpawn().y * TILE_SIZE + TILE_SIZE / 2,
      dir: 1, moving: false, hp: 100, mp: 50, gold: 40,
      inv: { hp: 3, mp: 3 }, attackCD: 0, alive: true, classKey: null,
      attrs: {}, statPoints: 0, classLevel: 1, classXp: 0,
      playerLevel: 1, playerXp: 0, kills: {}, questsDone: 0,
    } as Player;
  }, []);

  // ---- main loop ----
  useEffect(() => {
    if (!classChosen) return;
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext('2d')!;
    ctx.imageSmoothingEnabled = false;

    // resize canvas to fill screen (mobile-friendly)
    const resize = () => {
      canvas.width = Math.min(window.innerWidth, 480);
      canvas.height = Math.min(window.innerHeight, 720);
    };
    resize();
    window.addEventListener('resize', resize);

    loadFloor(stateRef.current.loc);

    const kd = (e: KeyboardEvent) => {
      stateRef.current.keys[e.key.toLowerCase()] = true;
      if (e.key === '1') usePotion('hp');
      if (e.key === '2') usePotion('mp');
    };
    const ku = (e: KeyboardEvent) => { stateRef.current.keys[e.key.toLowerCase()] = false; };
    window.addEventListener('keydown', kd);
    window.addEventListener('keyup', ku);

    let raf = 0;
    let last = performance.now();
    const dist = (ax: number, ay: number, bx: number, by: number) => Math.hypot(ax - bx, ay - by);

    function findNearestMonster(): Monster | null {
      const s = stateRef.current; const p = s.player;
      const d = getDerived();
      if (!d) return null;
      const range = d.range * TILE_SIZE + 30;
      let best: Monster | null = null; let bd = range;
      for (const m of s.monsters) {
        if (!m.alive) continue;
        const dd = dist(p.x, p.y, m.x, m.y);
        if (dd < bd) { bd = dd; best = m; }
      }
      return best;
    }

    function doAttack(m: Monster) {
      const s = stateRef.current; const p = s.player;
      const d = getDerived();
      if (!d || p.attackCD > 0) return;
      if (dist(p.x, p.y, m.x, m.y) > d.range * TILE_SIZE + 30) return;
      p.attackCD = 30;
      if (m.x < p.x) p.dir = -1; else p.dir = 1;
      const isCrit = Math.random() < d.critChance;
      const baseDmg = d.atk * (0.85 + Math.random() * 0.3);
      const dmg = Math.round(baseDmg * (isCrit ? d.critMult : 1));
      if (d.range > 1.5) {
        s.projectiles.push({ x: p.x, y: p.y - 10, tx: m.x, ty: m.y - 10, target: m, speed: 9, color: p.classKey === 'mago' ? '#3aa0ff' : '#e8d27a', done: false, crit: isCrit });
      } else {
        dealDamage(m, dmg, isCrit);
      }
    }

    function dealDamage(m: Monster, dmg: number, crit: boolean) {
      const s = stateRef.current;
      m.hp -= dmg; m.hitFlash = 8;
      s.floats.push({ x: m.x, y: m.y - 20, text: `${crit ? 'CRIT ' : ''}-${dmg}`, color: crit ? '#ff4444' : '#ffdd55', life: 50 });
      if (m.hp <= 0 && m.alive) killMonster(m);
    }

    function killMonster(m: Monster) {
      const s = stateRef.current; const p = s.player;
      const d = getDerived()!;
      m.alive = false;
      const goldDrop = Math.round((m.gold[0] + Math.floor(Math.random() * (m.gold[1] - m.gold[0] + 1))) * d.goldFind);
      p.gold += goldDrop;
      s.floats.push({ x: m.x, y: m.y - 10, text: `+${goldDrop}g`, color: '#d9a441', life: 50 });
      // class XP and player XP
      p.classXp += m.xp;
      p.playerXp += m.xp;
      p.kills[m.def.key] = (p.kills[m.def.key] || 0) + 1;
      // quest progress
      setQuests(prev => prev.map(q => {
        if (q.id === 'q1' && m.def.key === 'rat') return { ...q, progress: Math.min(q.total, q.progress + 1) };
        if (q.id === 'q2' && m.def.key === 'wolf') return { ...q, progress: Math.min(q.total, q.progress + 1) };
        return q;
      }));
      // class level up
      while (p.classXp >= classXpNext(p.classLevel)) {
        p.classXp -= classXpNext(p.classLevel);
        p.classLevel++;
        p.statPoints += 2;
        showBanner(`CLASSE NÍVEL ${p.classLevel}! +2 pontos`, '#5dade2');
        log(`Sua classe alcançou o nível ${p.classLevel}! +2 pontos de atributo.`);
      }
      // player level up (+5% power)
      while (p.playerXp >= playerXpNext(p.playerLevel)) {
        p.playerXp -= playerXpNext(p.playerLevel);
        p.playerLevel++;
        const nd = deriveStats(CLASS_DEFS[p.classKey!], p.attrs, p.classLevel, p.playerLevel);
        const heal = nd.maxHp - p.hp;
        p.hp = nd.maxHp; p.mp = nd.maxMp;
        showBanner(`NÍVEL ${p.playerLevel}! +5% poder`, '#58d68d');
        log(`Você alcançou o nível ${p.playerLevel}! +5% de poder. (+${heal} HP)`);
      }
      log(`Derrotou ${m.def.name} (Nv.${m.level}) (+${m.xp} XP, +${goldDrop}g).`);
      setTimeout(() => { stateRef.current.monsters = stateRef.current.monsters.filter(mm => mm !== m); }, 600);
      syncHud();
    }

    function die() {
      stateRef.current.player.alive = false;
      setDead(true);
    }

    function updatePlayer(dt: number) {
      const s = stateRef.current; const p = s.player;
      if (!p.alive || !p.classKey) return;
      const d = getDerived()!;
      let dx = 0, dy = 0;
      const k = s.keys;
      if (k['w'] || k['arrowup']) dy = -1;
      if (k['s'] || k['arrowdown']) dy = 1;
      if (k['a'] || k['arrowleft']) dx = -1;
      if (k['d'] || k['arrowright']) dx = 1;
      // joystick input
      if (s.joyVec.dx !== 0 || s.joyVec.dy !== 0) { dx = s.joyVec.dx; dy = s.joyVec.dy; }
      p.moving = (dx !== 0 || dy !== 0);
      if (dx !== 0) p.dir = dx < 0 ? -1 : 1;
      if (p.moving) {
        const len = Math.hypot(dx, dy) || 1;
        const step = d.speed * 1.6 * dt;
        const nx = p.x + (dx / len) * step;
        const ny = p.y + (dy / len) * step;
        const tryMove = (x: number, y: number) => {
          const r = 14;
          for (const [ox, oy] of [[-r, -r], [r, -r], [-r, r], [r, r], [0, 0]]) {
            if (isBlocked(Math.floor((x + ox) / TILE_SIZE), Math.floor((y + oy) / TILE_SIZE))) return false;
          }
          return true;
        };
        if (tryMove(nx, p.y)) p.x = nx;
        if (tryMove(p.x, ny)) p.y = ny;
      }
      if (p.attackCD > 0) p.attackCD--;
      // regen
      if (p.hp < d.maxHp) p.hp = Math.min(d.maxHp, p.hp + d.hpRegen * dt * 0.5);
      if (p.mp < d.maxMp) p.mp = Math.min(d.maxMp, p.mp + d.mpRegen * dt * 0.5);

      // auto-attack nearest in range
      if (s.autoAttack) {
        const target = findNearestMonster();
        if (target) doAttack(target);
      }

      // stair interaction
      const tx = Math.floor(p.x / TILE_SIZE), ty = Math.floor(p.y / TILE_SIZE);
      const fm = s.floorMap!;
      if (tx >= 0 && ty >= 0 && tx < fm.w && ty < fm.h) {
        const cell = fm.cells[ty][tx];
        if (cell.stairTo && p.moving && s.transitionFlash <= 0) {
          loadFloor(cell.stairTo);
        }
      }
    }

    function updateMonsters(dt: number) {
      const s = stateRef.current; const p = s.player;
      const d = getDerived();
      for (const m of s.monsters) {
        if (!m.alive) continue;
        if (m.hitFlash > 0) m.hitFlash--;
        const dd = dist(p.x, p.y, m.x, m.y);
        m.moving = false;
        if (p.alive && p.classKey && dd < 160) {
          const dx = p.x - m.x, dy = p.y - m.y;
          const len = Math.hypot(dx, dy) || 1;
          if (dx < 0) m.dir = -1; else m.dir = 1;
          if (dd > 30) {
            const nx = m.x + (dx / len) * m.def.speed * dt;
            const ny = m.y + (dy / len) * m.def.speed * dt;
            if (!isBlocked(Math.floor(nx / TILE_SIZE), Math.floor(ny / TILE_SIZE))) { m.x = nx; m.y = ny; }
            m.moving = true;
          } else if (m.cd <= 0) {
            m.cd = 55;
            let dmg = m.atk * (0.8 + Math.random() * 0.4);
            if (d) dmg *= (1 - d.dmgReduction);
            // dodge
            if (d && Math.random() < d.dodge) {
              s.floats.push({ x: p.x, y: p.y - 24, text: 'ESQUIVA', color: '#5dade2', life: 40 });
            } else {
              p.hp -= dmg;
              s.floats.push({ x: p.x, y: p.y - 24, text: `-${Math.round(dmg)}`, color: '#ff6b6b', life: 50 });
              s.shake = 6;
              if (p.hp <= 0) { p.hp = 0; die(); }
            }
          }
        } else {
          m.wanderT += dt;
          if (m.wanderT > 90) { m.wanderT = 0; m.wx = (Math.random() - 0.5) * 60; m.wy = (Math.random() - 0.5) * 60; }
          const txw = m.homeX + m.wx, tyw = m.homeY + m.wy;
          const dx = txw - m.x, dy = tyw - m.y, dd2 = Math.hypot(dx, dy);
          if (dd2 > 4) {
            const nx = m.x + (dx / dd2) * 0.4 * dt;
            const ny = m.y + (dy / dd2) * 0.4 * dt;
            if (!isBlocked(Math.floor(nx / TILE_SIZE), Math.floor(ny / TILE_SIZE))) { m.x = nx; m.y = ny; m.moving = true; }
          }
        }
        if (m.cd > 0) m.cd -= dt;
      }
    }

    function updateProjectiles() {
      const s = stateRef.current;
      for (const pj of s.projectiles) {
        if (pj.done) continue;
        if (pj.target) { pj.tx = pj.target.x; pj.ty = pj.target.y - 10; }
        const dx = pj.tx - pj.x, dy = pj.ty - pj.y, d = Math.hypot(dx, dy);
        if (d < pj.speed || !pj.target || !pj.target.alive) {
          pj.done = true;
          if (pj.target && pj.target.alive) {
            const dd = getDerived()!;
            const baseDmg = dd.atk * (0.85 + Math.random() * 0.3);
            const dmg = Math.round(baseDmg * (pj.crit ? dd.critMult : 1));
            dealDamage(pj.target, dmg, pj.crit);
          }
        } else { pj.x += dx / d * pj.speed; pj.y += dy / d * pj.speed; }
      }
      s.projectiles = s.projectiles.filter(pj => !pj.done);
    }

    function updateFloats() {
      const s = stateRef.current;
      s.floats = s.floats.filter(f => f.life > 0);
      for (const f of s.floats) { f.y -= 0.5; f.life--; }
    }

    function updateCamera() {
      const s = stateRef.current; const p = s.player;
      const fm = s.floorMap!;
      s.camX = p.x - canvas.width / 2;
      s.camY = p.y - canvas.height / 2;
      if (s.shake > 0) {
        s.camX += (Math.random() - 0.5) * s.shake;
        s.camY += (Math.random() - 0.5) * s.shake;
        s.shake *= 0.85;
        if (s.shake < 0.5) s.shake = 0;
      }
      s.camX = Math.max(0, Math.min(s.camX, fm.w * TILE_SIZE - canvas.width));
      s.camY = Math.max(0, Math.min(s.camY, fm.h * TILE_SIZE - canvas.height));
    }

    function drawSprite(img: HTMLImageElement, wx: number, wy: number, size: number, dir: number, flash: boolean) {
      const s = stateRef.current;
      const sx = wx - s.camX - size / 2, sy = wy - s.camY - size / 2;
      ctx.save();
      if (flash) ctx.filter = 'brightness(2) saturate(0)';
      if (dir < 0) { ctx.translate(sx + size, sy); ctx.scale(-1, 1); ctx.drawImage(img, 0, 0, size, size); }
      else ctx.drawImage(img, sx, sy, size, size);
      ctx.restore();
    }

    function drawDecor(cell: Cell, sx: number, sy: number) {
      if (!cell.decor) return;
      switch (cell.decor) {
        case 'torch': {
          ctx.drawImage(IMG.torch, sx + 8, sy - 4, 24, 32);
          const fl = 0.6 + Math.sin(Date.now() / 120) * 0.2;
          ctx.fillStyle = `rgba(255,180,60,${0.25 * fl})`;
          ctx.beginPath(); ctx.arc(sx + 20, sy + 6, 16, 0, Math.PI * 2); ctx.fill();
          break;
        }
        case 'rock': ctx.drawImage(IMG.box, sx + 4, sy + 4, 32, 32); break;
        case 'pillar': {
          ctx.fillStyle = 'rgba(90,86,80,0.9)'; ctx.fillRect(sx + 12, sy, 16, TILE_SIZE);
          ctx.fillStyle = 'rgba(120,116,108,0.9)'; ctx.fillRect(sx + 10, sy, 20, 6); ctx.fillRect(sx + 10, sy + TILE_SIZE - 6, 20, 6);
          break;
        }
        case 'bones': {
          ctx.fillStyle = 'rgba(220,214,200,0.8)';
          ctx.fillRect(sx + 10, sy + 20, 20, 3); ctx.fillRect(sx + 14, sy + 16, 3, 8); ctx.fillRect(sx + 24, sy + 16, 3, 8);
          break;
        }
        case 'crystal': {
          ctx.fillStyle = 'rgba(180,160,240,0.7)';
          ctx.beginPath(); ctx.moveTo(sx + 20, sy + 8); ctx.lineTo(sx + 28, sy + 24); ctx.lineTo(sx + 12, sy + 24); ctx.closePath(); ctx.fill();
          ctx.fillStyle = 'rgba(220,200,255,0.9)';
          ctx.beginPath(); ctx.moveTo(sx + 20, sy + 8); ctx.lineTo(sx + 24, sy + 18); ctx.lineTo(sx + 16, sy + 18); ctx.closePath(); ctx.fill();
          break;
        }
        case 'stairDown': {
          const pulse = 0.5 + Math.sin(Date.now() / 400) * 0.3;
          ctx.fillStyle = 'rgba(20,20,30,0.9)'; ctx.fillRect(sx + 4, sy + 4, TILE_SIZE - 8, TILE_SIZE - 8);
          ctx.strokeStyle = `rgba(120,200,255,${pulse})`; ctx.lineWidth = 2;
          for (let i = 0; i < 4; i++) ctx.strokeRect(sx + 6 + i * 3, sy + 6 + i * 3, TILE_SIZE - 12 - i * 6, TILE_SIZE - 12 - i * 6);
          ctx.fillStyle = `rgba(80,160,255,${pulse * 0.4})`;
          ctx.beginPath(); ctx.arc(sx + 20, sy + 20, 14, 0, Math.PI * 2); ctx.fill();
          break;
        }
        case 'stairUp': {
          const pulse = 0.5 + Math.sin(Date.now() / 400 + 1) * 0.3;
          ctx.fillStyle = 'rgba(40,30,20,0.9)'; ctx.fillRect(sx + 4, sy + 4, TILE_SIZE - 8, TILE_SIZE - 8);
          ctx.strokeStyle = `rgba(220,180,80,${pulse})`; ctx.lineWidth = 2;
          for (let i = 0; i < 4; i++) ctx.strokeRect(sx + 6 + i * 3, sy + 6 + i * 3, TILE_SIZE - 12 - i * 6, TILE_SIZE - 12 - i * 6);
          ctx.fillStyle = `rgba(255,200,80,${pulse * 0.4})`;
          ctx.beginPath(); ctx.arc(sx + 20, sy + 20, 14, 0, Math.PI * 2); ctx.fill();
          break;
        }
      }
    }

    function render() {
      const s = stateRef.current;
      const fm = s.floorMap!;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      updateCamera();
      const startX = Math.max(0, Math.floor(s.camX / TILE_SIZE));
      const endX = Math.min(fm.w, Math.ceil((s.camX + canvas.width) / TILE_SIZE) + 1);
      const startY = Math.max(0, Math.floor(s.camY / TILE_SIZE));
      const endY = Math.min(fm.h, Math.ceil((s.camY + canvas.height) / TILE_SIZE) + 1);

      for (let y = startY; y < endY; y++) {
        for (let x = startX; x < endX; x++) {
          const cell = fm.cells[y][x];
          const sx = x * TILE_SIZE - s.camX, sy = y * TILE_SIZE - s.camY;
          if (cell.wall) {
            drawTile(ctx, cell.floor as TileKind, sx, sy, x, y);
            const wb = BIOME_BY_ID.get(cell.biome)!;
            drawTile(ctx, wb.wall, sx, sy, x + 100, y + 100);
            ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(sx, sy + TILE_SIZE - 6, TILE_SIZE + 1, 6);
          } else {
            drawTile(ctx, cell.floor, sx, sy, x, y);
          }
        }
      }
      for (let y = startY; y < endY; y++)
        for (let x = startX; x < endX; x++)
          if (fm.cells[y][x].decor) drawDecor(fm.cells[y][x], x * TILE_SIZE - s.camX, y * TILE_SIZE - s.camY);

      const biome = biomeAt(s.loc);
      ctx.fillStyle = biome.ambient; ctx.fillRect(0, 0, canvas.width, canvas.height);

      const entities: { type: 'm' | 'p'; ref: Monster | Player; y: number }[] = [];
      for (const m of s.monsters) if (m.alive) entities.push({ type: 'm', ref: m, y: m.y });
      entities.push({ type: 'p', ref: s.player, y: s.player.y });
      entities.sort((a, b) => a.y - b.y);

      for (const e of entities) {
        if (e.type === 'm') {
          const m = e.ref as Monster;
          ctx.drawImage(IMG.shadow, m.x - s.camX - 14, m.y - s.camY + 8, 28, 12);
          const img = IMG[m.moving ? m.def.move : m.def.idle];
          drawSprite(img, m.x, m.y, 36, m.dir, m.hitFlash > 0);
          const w = 30;
          ctx.fillStyle = '#000'; ctx.fillRect(m.x - s.camX - w / 2, m.y - s.camY - 26, w, 5);
          ctx.fillStyle = '#c0392b'; ctx.fillRect(m.x - s.camX - w / 2, m.y - s.camY - 26, w * (m.hp / m.maxHp), 5);
          ctx.fillStyle = '#fff'; ctx.font = '9px sans-serif'; ctx.textAlign = 'center';
          ctx.fillText(`${m.def.name} Nv.${m.level}`, m.x - s.camX, m.y - s.camY - 29);
        } else {
          const p = e.ref as Player;
          if (!p.alive || !p.classKey) continue;
          ctx.drawImage(IMG.shadow, p.x - s.camX - 15, p.y - s.camY + 10, 30, 13);
          const c = CLASS_DEFS[p.classKey];
          const img = IMG[p.moving ? c.move : c.idle];
          drawSprite(img, p.x, p.y, 40, p.dir, false);
        }
      }

      // merchant
      if (s.loc.floor === 0) {
        const mp = s.merchantPos;
        const mx = mp.tx * TILE_SIZE + TILE_SIZE / 2, my = mp.ty * TILE_SIZE + TILE_SIZE / 2;
        if (mx >= s.camX - 40 && mx <= s.camX + canvas.width + 40) {
          ctx.drawImage(IMG.shadow, mx - s.camX - 15, my - s.camY + 10, 30, 13);
          drawSprite(IMG.merchantIdle, mx, my, 40, 1, false);
          ctx.fillStyle = '#d9a441'; ctx.font = '10px sans-serif'; ctx.textAlign = 'center';
          ctx.fillText('Comerciante', mx - s.camX, my - s.camY - 26);
        }
      }

      // projectiles
      for (const pj of s.projectiles) {
        ctx.beginPath(); ctx.fillStyle = pj.color;
        ctx.shadowColor = pj.color; ctx.shadowBlur = 8;
        ctx.arc(pj.x - s.camX, pj.y - s.camY, pj.crit ? 7 : 5, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
      }

      ctx.font = 'bold 13px sans-serif'; ctx.textAlign = 'center';
      for (const f of s.floats) {
        ctx.globalAlpha = Math.min(1, f.life / 20); ctx.fillStyle = f.color;
        ctx.fillText(f.text, f.x - s.camX, f.y - s.camY);
      }
      ctx.globalAlpha = 1;

      if (s.transitionFlash > 0) {
        ctx.fillStyle = `rgba(0,0,0,${s.transitionFlash / 30})`;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        s.transitionFlash--;
      }
    }

    const loop = (now: number) => {
      const dt = Math.min(2, (now - last) / 16.67);
      last = now;
      updatePlayer(dt);
      updateMonsters(dt);
      updateFloats();
      updateProjectiles();
      render();
      if (stateRef.current.logQueue.length) {
        const q = stateRef.current.logQueue.splice(0);
        setLogs(prev => [...q.reverse(), ...prev].slice(0, 5));
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('keydown', kd);
      window.removeEventListener('keyup', ku);
      window.removeEventListener('resize', resize);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [classChosen]);

  // ---- joystick handlers ----
  const joyRef = useRef<HTMLDivElement>(null);
  const onJoyStart = (e: React.TouchEvent | React.MouseEvent) => {
    e.preventDefault();
    setJoystick(j => ({ ...j, active: true }));
  };
  const onJoyMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!joystick.active) return;
    const el = joyRef.current; if (!el) return;
    const r = el.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    let dx = (clientX - cx) / (r.width / 2);
    let dy = (clientY - cy) / (r.height / 2);
    const len = Math.hypot(dx, dy);
    if (len > 1) { dx /= len; dy /= len; }
    setJoystick(j => ({ ...j, dx, dy }));
    stateRef.current.joyVec = { dx, dy };
  };
  const onJoyEnd = () => {
    setJoystick({ active: false, dx: 0, dy: 0 });
    stateRef.current.joyVec = { dx: 0, dy: 0 };
  };

  const onAttackBtn = () => {
    const target = (function findNearest() {
      const s = stateRef.current; const p = s.player;
      const d = getDerived(); if (!d) return null;
      const range = d.range * TILE_SIZE + 30;
      let best: Monster | null = null; let bd = range;
      for (const m of s.monsters) {
        if (!m.alive) continue;
        const dd = Math.hypot(p.x - m.x, p.y - m.y);
        if (dd < bd) { bd = dd; best = m; }
      }
      return best;
    })();
    if (target) {
      // trigger attack via a custom event the loop reads
      stateRef.current.autoAttack = true;
      setTimeout(() => { stateRef.current.autoAttack = false; }, 300);
    } else {
      log('Nenhum inimigo no alcance.');
    }
  };

  const onInteract = () => {
    const p = stateRef.current.player;
    const mp = stateRef.current.merchantPos;
    if (Math.hypot(p.x - (mp.tx * TILE_SIZE + TILE_SIZE / 2), p.y - (mp.ty * TILE_SIZE + TILE_SIZE / 2)) < 70) {
      setModal('shop');
    } else log('Aproxime-se do comerciante para negociar.');
  };

  // ---- derived data for modals ----
  const p = stateRef.current.player;
  const derived = getDerived();
  const invItems: InvItem[] = ([
    { key: 'hp', name: 'Poção de Vida', img: 'lifepotionpequena', qty: p.inv.hp, type: 'potion' as const, desc: 'Restaura 40 HP' },
    { key: 'mp', name: 'Poção de Mana', img: 'manapotionpequena', qty: p.inv.mp, type: 'potion' as const, desc: 'Restaura 30 MP' },
  ] as InvItem[]).filter(i => i.qty > 0);

  const equipSlots: EquipSlot[] = p.classKey ? [
    { slot: 'Arma', name: CLASS_DEFS[p.classKey].key === 'guerreiro' ? 'Espada de Aço' : CLASS_DEFS[p.classKey].key === 'arqueiro' ? 'Arco de Ferro' : 'Cajado Místico', img: CLASS_DEFS[p.classKey].key === 'guerreiro' ? 'espadadeacolv275' : CLASS_DEFS[p.classKey].key === 'arqueiro' ? 'arcodeferrolv75' : 'cajadomisticolv175' },
    { slot: 'Escudo', name: 'Escudo de Aço', img: 'escudodeacolv75' },
    { slot: 'Armadura', name: 'Armadura de Couro', img: null },
    { slot: 'Capacete', name: '—', img: null },
  ] : [];

  return (
    <div className="relative w-full h-screen flex items-center justify-center bg-[#0b0805] overflow-hidden font-[Trebuchet_MS,Verdana,sans-serif] text-gray-200 select-none">
      <canvas
        ref={canvasRef}
        className="touch-none"
        style={{ imageRendering: 'pixelated', maxWidth: '100vw', maxHeight: '100vh' }}
      />

      {/* HUD top */}
      {classChosen && derived && (
        <>
          <div className="absolute top-1.5 left-1.5 flex flex-col gap-1 z-[5] pointer-events-none">
            <div className="text-[11px] bg-black/60 px-1.5 py-0.5 rounded border border-[#5c3d1e] w-fit">
              Nv.{hud.playerLevel} · {hud.className} Nv.{hud.classLevel}
            </div>
            <Bar label={`${hud.hp}/${hud.maxHp}`} pct={hud.hp / hud.maxHp} from="#e74c3c" to="#c0392b" w={140} />
            <Bar label={`${hud.mp}/${hud.maxMp}`} pct={hud.mp / hud.maxMp} from="#5dade2" to="#2980b9" w={140} />
            <Bar label={`${hud.playerXp}/${hud.playerXpNext}`} pct={hud.playerXp / hud.playerXpNext} from="#58d68d" to="#27ae60" w={140} />
            {hud.statPoints > 0 && (
              <div className="text-[10px] bg-[#d9a441] text-black px-1.5 py-0.5 rounded font-bold w-fit animate-pulse">
                {hud.statPoints} pontos livres!
              </div>
            )}
          </div>

          <div className="absolute top-1.5 right-1.5 z-[5] bg-black/60 border border-[#d9a441] rounded-md px-2 py-1 text-xs flex items-center gap-1">
            <img src={ASSET('esmeralda')} className="w-4 h-4" style={{ imageRendering: 'pixelated' }} />
            <span>{hud.gold}</span>
          </div>
          <div className="absolute top-12 right-1.5 z-[5] bg-black/60 border border-[#5c3d1e] rounded-md px-2 py-0.5 text-[10px] text-[#d9a441]">
            {biomeLabel}
          </div>

          {/* log */}
          <div className="absolute top-20 left-1.5 w-[150px] max-h-[80px] overflow-hidden z-[5] text-[10px] flex flex-col-reverse gap-0.5 pointer-events-none">
            {logs.map((l, i) => (
              <div key={i} className="bg-black/50 px-1 py-0.5 rounded border-l-2 border-[#d9a441] truncate">{l}</div>
            ))}
          </div>

          {/* ---- Mobile controls: joystick + action buttons ---- */}
          {/* Joystick (left) */}
          <div
            ref={joyRef}
            className="absolute bottom-20 left-4 w-28 h-28 rounded-full bg-black/30 border-2 border-[#5c3d1e] z-[10] touch-none flex items-center justify-center"
            onTouchStart={onJoyStart}
            onTouchMove={onJoyMove}
            onTouchEnd={onJoyEnd}
            onMouseDown={onJoyStart}
            onMouseMove={onJoyMove}
            onMouseUp={onJoyEnd}
            onMouseLeave={onJoyEnd}
          >
            <div
              className="w-12 h-12 rounded-full bg-[#d9a441]/60 border-2 border-[#d9a441] transition-transform"
              style={{ transform: `translate(${joystick.dx * 28}px, ${joystick.dy * 28}px)` }}
            />
          </div>

          {/* Action buttons (right) */}
          <div className="absolute bottom-20 right-4 flex flex-col gap-2 z-[10]">
            <div className="flex gap-2">
              <ActionBtn label="ATK" color="#c0392b" onPress={onAttackBtn} />
              <ActionBtn label="INT" color="#d9a441" onPress={onInteract} />
            </div>
            <div className="flex gap-2">
              <ActionBtn label="HP" color="#e74c3c" onPress={() => usePotion('hp')} small />
              <ActionBtn label="MP" color="#2980b9" onPress={() => usePotion('mp')} small />
            </div>
          </div>

          {/* ---- Menu bar (bottom) ---- */}
          <div className="absolute bottom-1.5 left-1/2 -translate-x-1/2 flex gap-1 z-[10] bg-black/50 p-1 rounded-lg border border-[#5c3d1e]">
            <MenuBtn label="Status" icon="📊" onClick={() => setModal('status')} />
            <MenuBtn label="Mochila" icon="🎒" onClick={() => setModal('inventory')} />
            <MenuBtn label="Mapa" icon="🗺️" onClick={() => setModal('map')} />
            <MenuBtn label="Equip" icon="⚔️" onClick={() => setModal('equipment')} />
            <MenuBtn label="Skills" icon="✨" onClick={() => setModal('skills')} />
            <MenuBtn label="Best." icon="📖" onClick={() => setModal('bestiary')} />
            <MenuBtn label="Miss." icon="📜" onClick={() => setModal('quests')} />
            <MenuBtn label="Conf." icon="⚙️" onClick={() => setModal('settings')} />
          </div>

          {/* banner */}
          {banner && (
            <div className="absolute top-[35%] left-1/2 -translate-x-1/2 -translate-y-1/2 z-[15] text-xl font-bold pointer-events-none"
              style={{ color: banner.color, textShadow: '2px 2px #000', animation: 'fadeUp 1.4s ease forwards' }}>
              {banner.text}
            </div>
          )}

          {/* ---- Modals ---- */}
          {modal === 'status' && derived && (
            <StatusModal
              attrs={p.attrs} statPoints={p.statPoints} classKey={p.classKey!}
              classLevel={p.classLevel} classXp={p.classXp} classXpNext={classXpNext(p.classLevel)}
              playerLevel={p.playerLevel} derived={derived}
              onAddAttr={addAttr} onClose={() => setModal(null)}
            />
          )}
          {modal === 'inventory' && (
            <InventoryModal items={invItems} gold={p.gold} onClose={() => setModal(null)} onUse={(k) => usePotion(k as 'hp' | 'mp')} />
          )}
          {modal === 'map' && (
            <WorldMapModal currentBiome={stateRef.current.loc.biome} maxOrder={stateRef.current.maxOrderReached} onClose={() => setModal(null)} />
          )}
          {modal === 'equipment' && (
            <EquipmentModal slots={equipSlots} onClose={() => setModal(null)} />
          )}
          {modal === 'skills' && p.classKey && (
            <SkillsModal classKey={p.classKey} classLevel={p.classLevel} onClose={() => setModal(null)} />
          )}
          {modal === 'bestiary' && <BestiaryModal kills={p.kills} onClose={() => setModal(null)} />}
          {modal === 'quests' && <QuestsModal quests={quests} onClose={() => setModal(null)} />}
          {modal === 'settings' && (
            <SettingsModal soundOn={soundOn} onToggleSound={() => setSoundOn(s => !s)} onReset={resetGame} onClose={() => setModal(null)} />
          )}
          {modal === 'shop' && (
            <div className="absolute inset-0 bg-black/70 z-[30] flex items-center justify-center p-3" onClick={() => setModal(null)}>
              <div className="bg-[#1a1410] border-2 border-[#d9a441] rounded-xl p-4 w-full max-w-sm" onClick={e => e.stopPropagation()}>
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-base font-bold text-[#d9a441]">Comerciante Errante</h2>
                  <button className="text-[#bba] text-xl px-2" onClick={() => setModal(null)}>×</button>
                </div>
                <ShopRow img="lifepotionpequena" name="Poção de Vida" cost={Math.round(15 * (1 - (derived.shopDiscount || 0)))} onClick={() => buyPotion('hp')} />
                <ShopRow img="manapotionpequena" name="Poção de Mana" cost={Math.round(15 * (1 - (derived.shopDiscount || 0)))} onClick={() => buyPotion('mp')} />
              </div>
            </div>
          )}

          {/* death */}
          {dead && (
            <div className="absolute inset-0 bg-red-900/60 z-[40] flex flex-col items-center justify-center gap-3">
              <h1 className="text-[#ff6b6b] text-2xl" style={{ textShadow: '2px 2px #000' }}>Você caiu em combate</h1>
              <p className="text-gray-300 text-sm">Nível: {hud.playerLevel} · Ouro: {hud.gold}</p>
              <button className="px-5 py-2.5 text-sm bg-[#d9a441] border-none rounded cursor-pointer font-bold" onClick={revive}>
                Renascer
              </button>
            </div>
          )}
        </>
      )}

      {/* class select */}
      {!classChosen && (
        <div className="absolute inset-0 bg-black/92 z-[20] flex flex-col items-center justify-center gap-4 p-4 overflow-y-auto">
          <h1 className="text-2xl tracking-wider text-[#d9a441] text-center" style={{ textShadow: '2px 2px #000' }}>ALDENOR — Crônicas Esquecidas</h1>
          <p className="text-[#bba] text-[13px]">Escolha sua classe</p>
          <div className="flex flex-col sm:flex-row gap-3 w-full max-w-md">
            {Object.entries(CLASS_DEFS).map(([key, c]) => (
              <div key={key} className="flex-1 bg-[#1a1410] border-2 border-[#5c3d1e] rounded-lg p-3 text-center cursor-pointer transition-all active:scale-95 hover:border-[#d9a441]"
                onClick={() => setClass(key)}>
                <img src={ASSET(c.idle.replace('Idle', 'agaichado'))} className="w-14 h-14 mx-auto" style={{ imageRendering: 'pixelated' }} />
                <h3 className="my-1.5 text-sm text-[#d9a441]">{c.name}</h3>
                <p className="text-[10px] text-[#bba] leading-snug">{c.desc}</p>
              </div>
            ))}
          </div>
          <div className="text-[#bba] text-[11px] max-w-sm text-center mt-1">
            12 biomas com 4 andares cada. Sistema de atributos com 10 stats, nível de classe (+2 pts/nível) e nível de player (+5% poder). Controles mobile: joystick à esquerda, botões à direita.
          </div>
        </div>
      )}

      <style>{`
        @keyframes fadeUp {
          0% { opacity: 0; transform: translate(-50%, -30%) scale(0.7); }
          15% { opacity: 1; transform: translate(-50%, -50%) scale(1.05); }
          80% { opacity: 1; }
          100% { opacity: 0; transform: translate(-50%, -70%) scale(1); }
        }
      `}</style>
    </div>
  );
}

function Bar({ label, pct, from, to, w }: { label: string; pct: number; from: string; to: string; w: number }) {
  return (
    <div className="bg-black border-2 border-black rounded relative overflow-hidden shadow-[0_0_0_1px_#4a3318]" style={{ width: w, height: 14 }}>
      <div className="h-full transition-[width] duration-200" style={{ width: `${Math.min(1, pct) * 100}%`, background: `linear-gradient(${from}, ${to})` }} />
      <div className="absolute inset-0 flex items-center justify-center text-[9px] font-bold" style={{ textShadow: '1px 1px 1px #000' }}>{label}</div>
    </div>
  );
}

function ActionBtn({ label, color, onPress, small }: { label: string; color: string; onPress: () => void; small?: boolean }) {
  const size = small ? 'w-12 h-12 text-[10px]' : 'w-16 h-16 text-xs';
  return (
    <button
      className={`${size} rounded-full border-2 font-bold active:scale-90 transition-transform touch-none flex items-center justify-center`}
      style={{ backgroundColor: color + '99', borderColor: color, color: '#fff', textShadow: '1px 1px 1px #000' }}
      onTouchStart={(e) => { e.preventDefault(); onPress(); }}
      onClick={onPress}
    >
      {label}
    </button>
  );
}

function MenuBtn({ label, icon, onClick }: { label: string; icon: string; onClick: () => void }) {
  return (
    <button className="flex flex-col items-center justify-center w-10 h-10 rounded bg-[#241a10] border border-[#3a2a16] active:scale-90 transition-transform" onClick={onClick}>
      <span className="text-base leading-none">{icon}</span>
      <span className="text-[7px] text-[#bba] mt-0.5">{label}</span>
    </button>
  );
}

function ShopRow({ img, name, cost, onClick }: { img: string; name: string; cost: number; onClick: () => void }) {
  return (
    <div className="flex items-center gap-2.5 p-1.5 rounded cursor-pointer hover:bg-[#2a1d10]" onClick={onClick}>
      <img src={ASSET(img)} className="w-7 h-7" style={{ imageRendering: 'pixelated' }} />
      <span className="flex-1 text-[13px]">{name}</span>
      <b className="text-[#d9a441] text-xs">{cost}g</b>
    </div>
  );
}
