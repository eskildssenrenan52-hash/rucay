// World map data: positions of biomes on a stylized world map for the
// "Mapa Mundi" modal. Positions are normalized 0..1 on the map image.

import { BIOMES, BiomeDef } from './biomes';

export interface MapNode {
  biome: BiomeDef;
  x: number; y: number; // 0..1 normalized
  unlocked: boolean;
}

// Arrange biomes in a rough spiral / scattered layout around the center spawn.
const POSITIONS: Record<string, { x: number; y: number }> = {
  sewers: { x: 0.5, y: 0.5 },       // center (spawn)
  forest: { x: 0.3, y: 0.35 },
  koboldcave: { x: 0.7, y: 0.3 },
  ruins: { x: 0.2, y: 0.6 },
  lizardmarsh: { x: 0.8, y: 0.55 },
  frostcavern: { x: 0.55, y: 0.2 },
  spiderlair: { x: 0.4, y: 0.8 },
  golemhall: { x: 0.75, y: 0.75 },
  coralreef: { x: 0.15, y: 0.3 },
  volcanic: { x: 0.85, y: 0.4 },
  mushroomgrove: { x: 0.6, y: 0.85 },
  dragonlair: { x: 0.3, y: 0.15 },
};

export function worldMapNodes(_currentBiome: string, maxOrderReached: number): MapNode[] {
  return BIOMES.map(b => {
    const pos = POSITIONS[b.id] || { x: 0.5, y: 0.5 };
    return {
      biome: b,
      x: pos.x, y: pos.y,
      unlocked: b.order <= maxOrderReached,
    };
  });
}

// Bestiary: all monster defs grouped by biome theme
export function bestiaryData() {
  return BIOMES.map(b => ({
    biome: b,
    theme: b.theme,
  }));
}
