// Character attributes system: 10 attributes per class, class level (grants
// +2 attribute points per level) and player level (+5% power per level).
// Enemies use the same scaling logic.

export interface AttrDef {
  key: string;
  name: string;
  desc: string;
  icon: string; // emoji-free; we use a short label
}

export const ATTRIBUTES: AttrDef[] = [
  { key: 'str', name: 'Força', desc: 'Aumenta dano físico e vida máxima.', icon: 'STR' },
  { key: 'dex', name: 'Destreza', desc: 'Aumenta velocidade, esquiva e crítico.', icon: 'DEX' },
  { key: 'int', name: 'Inteligência', desc: 'Aumenta dano mágico e mana máxima.', icon: 'INT' },
  { key: 'vit', name: 'Vitalidade', desc: 'Aumenta vida máxima e regeneração.', icon: 'VIT' },
  { key: 'agi', name: 'Agilidade', desc: 'Aumenta velocidade de ataque e movimento.', icon: 'AGI' },
  { key: 'res', name: 'Resistência', desc: 'Reduz dano recebido.', icon: 'RES' },
  { key: 'foc', name: 'Foco', desc: 'Aumenta precisão e alcance mágico.', icon: 'FOC' },
  { key: 'lck', name: 'Sorte', desc: 'Aumenta chance de crítico e drop de ouro.', icon: 'LCK' },
  { key: 'end', name: 'Energia', desc: 'Aumenta regeneração de mana e estamina.', icon: 'END' },
  { key: 'cha', name: 'Carisma', desc: 'Reduz preços de lojas e melhora recompensas.', icon: 'CHA' },
];

export type AttrMap = Record<string, number>;

export interface ClassDef {
  key: string;
  name: string;
  desc: string;
  baseHp: number; baseMp: number; baseAtk: number; range: number; speed: number;
  idle: string; move: string; color: string;
  // starting attribute distribution (total should be ~30)
  baseAttrs: AttrMap;
  // which attributes this class favors (for auto-level-up suggestions)
  favored: string[];
}

export const CLASS_DEFS: Record<string, ClassDef> = {
  guerreiro: {
    key: 'guerreiro',
    name: 'Guerreiro', desc: 'Alta vida e dano corpo a corpo. Ideal para iniciantes.',
    baseHp: 120, baseMp: 30, baseAtk: 14, range: 1, speed: 2.2,
    idle: 'guerreiroIdle', move: 'guerreiroMove', color: '#e67e22',
    baseAttrs: { str: 8, dex: 4, int: 1, vit: 7, agi: 3, res: 5, foc: 2, lck: 2, end: 3, cha: 2 },
    favored: ['str', 'vit', 'res'],
  },
  arqueiro: {
    key: 'arqueiro',
    name: 'Arqueira', desc: 'Ataques à distância e velocidade. Risco e recompensa.',
    baseHp: 85, baseMp: 50, baseAtk: 11, range: 4, speed: 2.7,
    idle: 'arqueiroIdle', move: 'arqueiroMove', color: '#27ae60',
    baseAttrs: { str: 3, dex: 8, int: 2, vit: 4, agi: 7, res: 3, foc: 5, lck: 4, end: 3, cha: 2 },
    favored: ['dex', 'agi', 'foc'],
  },
  mago: {
    key: 'mago',
    name: 'Mago', desc: 'Feitiços poderosos, mas vida e mana limitadas.',
    baseHp: 70, baseMp: 90, baseAtk: 18, range: 3.5, speed: 2.2,
    idle: 'magoIdle', move: 'magoMove', color: '#2980b9',
    baseAttrs: { str: 1, dex: 3, int: 9, vit: 3, agi: 2, res: 3, foc: 7, lck: 3, end: 5, cha: 2 },
    favored: ['int', 'foc', 'end'],
  },
};

// Derived stats from attributes + class + player level
export interface DerivedStats {
  maxHp: number; maxMp: number; atk: number; range: number; speed: number;
  critChance: number; critMult: number; dodge: number; dmgReduction: number;
  hpRegen: number; mpRegen: number; goldFind: number; shopDiscount: number;
}

export function deriveStats(
  cls: ClassDef,
  attrs: AttrMap,
  classLevel: number,
  playerLevel: number,
): DerivedStats {
  const a = attrs;
  // player level gives +5% per level to all core stats
  const playerMult = 1 + (playerLevel - 1) * 0.05;
  // class level gives +3% per level to core stats
  const classMult = 1 + (classLevel - 1) * 0.03;

  const maxHp = Math.round((cls.baseHp + a.vit * 6 + a.str * 2 + a.end * 3) * playerMult * classMult);
  const maxMp = Math.round((cls.baseMp + a.int * 5 + a.foc * 3 + a.end * 4) * playerMult * classMult);
  const atk = Math.round((cls.baseAtk + a.str * 1.5 + a.dex * 1.2 + a.int * 1.8) * playerMult * classMult);
  const range = cls.range + a.foc * 0.15;
  const speed = cls.speed + a.agi * 0.05 + a.dex * 0.03;
  const critChance = Math.min(0.6, 0.05 + a.dex * 0.012 + a.lck * 0.01);
  const critMult = 1.5 + a.str * 0.02;
  const dodge = Math.min(0.4, a.agi * 0.01 + a.dex * 0.008);
  const dmgReduction = Math.min(0.6, a.res * 0.015 + a.vit * 0.005);
  const hpRegen = a.vit * 0.08 + a.end * 0.05;
  const mpRegen = a.int * 0.06 + a.end * 0.08 + a.foc * 0.04;
  const goldFind = 1 + a.lck * 0.03 + a.cha * 0.02;
  const shopDiscount = Math.min(0.5, a.cha * 0.03);

  return {
    maxHp, maxMp, atk, range, speed, critChance, critMult, dodge,
    dmgReduction, hpRegen, mpRegen, goldFind, shopDiscount,
  };
}

// XP needed for next class level (separate from player level)
export function classXpNext(level: number): number {
  return Math.round(40 * Math.pow(1.3, level - 1) + 10);
}

// XP needed for next player level
export function playerXpNext(level: number): number {
  return Math.round(50 * Math.pow(1.35, level - 1) + 15);
}

// Enemy scaling: same logic — enemy "level" acts as both class+player level
export function enemyScale(level: number): number {
  return 1 + (level - 1) * 0.05 + (level - 1) * 0.03;
}
